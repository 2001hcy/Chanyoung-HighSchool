﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POS
{
    public class Menu
    {
        public string name; //음식 이름
        public int price;   //음식 가격
        public int count;   //음식 갯수
        public string Category; //음식 카테고리 
        public string imgPath;  //음식 사진 경로

        public Menu(string name, int price, string category,string imgPath)
        {
            this.name = name;
            this.price = price;
            this.Category = category;
            this.imgPath = imgPath;
        }

    }
}
