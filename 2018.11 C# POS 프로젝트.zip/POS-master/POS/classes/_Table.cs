﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POS
{
    public class _Table
    {
        public int tablenum;    //테이블 번호
        public List<Menu> listMenu; //해당 테이블이 어떤 음식을 몇 개 주문했는지 저장하는 리스트 
        public DateTime Ordertime;  //해당 테이블의 주문시간(마지막 주문시간)
        public _Table()
        {

        }

    }
}
