﻿namespace POS.classes
{
    public class History
    {
        public string name;     //음식 이름 
        public string category; //카테고리 
        public string pay;  //결제방법
        public int price;   //가격
        public int count;   //판매량
        public History(string name,string category,int price)
        {
            this.name = name;
            this.category = category;
            this.price = price;
        }
    }
}
