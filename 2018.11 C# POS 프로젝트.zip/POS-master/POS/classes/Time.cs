﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POS
{
    public class Time
    {
        public static DateTime time = DateTime.Now;
        public static string TIME;
        public static void Load()   //DateTime 변수를 현재 시간으로 초기화
        {
            time = DateTime.Now;
        }
        public static void Set()    //time 변수를 이용해서 필요한 문자열로 만듬 
        {
            int year = time.Year;
            int month = time.Month;
            int day = time.Day;
            int hour = time.Hour;
            int min = time.Minute;
            int sec = time.Second;
            TIME = year + "년" + month + "월" + day + "일" + hour + "시" + min + "분" + sec + "초";
        }
    }
}
