﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class Categories : Form
    {
        public delegate void OrderEventHandler(object sender, EventHandler e,string menu);
        public event OrderEventHandler Menu_Select;

        public Categories()
        {
            InitializeComponent();
        }

        private void MenuSelect(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string menu ="";
            switch (button.Name)
            {
                case "btnKB":
                case "CbtnKB":
                    menu = "김밥";
                    break;
                case "btnTKB":
                case "CbtnTKB":
                    menu = "참치김밥";
                    break;
                case "btnDKB":
                case "CbtnDKB":
                    menu = "돈까스김밥";
                    break;
                case "btnRamen":
                case "CbtnRamen":
                    menu = "라면";
                    break;
                case "btnUdon":
                case "CbtnUdon":
                    menu = "우동";
                    break;
                case "btnNoodle":
                case "CbtnNoodle":
                    menu = "잔치국수";
                    break;
                case "btnBBB":
                case "CbtnBBB":
                    menu = "비빔밥";
                    break;
                case "btnTofu":
                case "CbtnTofu":
                    menu = "순두부찌개";
                    break;
                case "btnCurry":
                case "CbtnCurry":
                    menu = "카레라이스";
                    break;
                case "btnPepsi":
                case "CbtnPepsi":
                    menu = "펩시";
                    break;
                case "btnCoke":
                case "CbtnCoke":
                    menu = "코카콜라";
                    break;
            }
            Menu_Select.Invoke(this, null,menu);
        }
    }
}
