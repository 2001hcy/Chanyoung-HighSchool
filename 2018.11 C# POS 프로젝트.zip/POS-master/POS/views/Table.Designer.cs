﻿namespace POS
{
    partial class Table
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TableName = new System.Windows.Forms.Label();
            this.Label_Time = new System.Windows.Forms.Label();
            this.OrderList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnOrder = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnCancelALL = new System.Windows.Forms.Button();
            this.btnIncreaseQty = new System.Windows.Forms.Button();
            this.btnDecreaseQty = new System.Windows.Forms.Button();
            this.lbTotal = new System.Windows.Forms.Label();
            this.imgSelected = new System.Windows.Forms.PictureBox();
            this.btnCat_All = new System.Windows.Forms.Button();
            this.btnCat_KB = new System.Windows.Forms.Button();
            this.btnCat_Meal = new System.Windows.Forms.Button();
            this.btnCat_Noodle = new System.Windows.Forms.Button();
            this.Radio_Card = new System.Windows.Forms.RadioButton();
            this.Radio_Cash = new System.Windows.Forms.RadioButton();
            this.btnPay = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCat_Beverage = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.imgSelected)).BeginInit();
            this.SuspendLayout();
            // 
            // TableName
            // 
            this.TableName.AutoSize = true;
            this.TableName.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.TableName.Location = new System.Drawing.Point(12, 9);
            this.TableName.Name = "TableName";
            this.TableName.Size = new System.Drawing.Size(79, 32);
            this.TableName.TabIndex = 0;
            this.TableName.Text = "label1";
            // 
            // Label_Time
            // 
            this.Label_Time.AutoSize = true;
            this.Label_Time.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_Time.Location = new System.Drawing.Point(267, 9);
            this.Label_Time.Name = "Label_Time";
            this.Label_Time.Size = new System.Drawing.Size(111, 32);
            this.Label_Time.TabIndex = 1;
            this.Label_Time.Text = "주문시간";
            // 
            // OrderList
            // 
            this.OrderList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.OrderList.GridLines = true;
            this.OrderList.Location = new System.Drawing.Point(18, 53);
            this.OrderList.Margin = new System.Windows.Forms.Padding(0);
            this.OrderList.Name = "OrderList";
            this.OrderList.Size = new System.Drawing.Size(360, 202);
            this.OrderList.TabIndex = 2;
            this.OrderList.UseCompatibleStateImageBehavior = false;
            this.OrderList.View = System.Windows.Forms.View.Details;
            this.OrderList.SelectedIndexChanged += new System.EventHandler(this.OrderList_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "상품명";
            this.columnHeader1.Width = 200;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "수량";
            this.columnHeader2.Width = 75;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "금액";
            this.columnHeader3.Width = 75;
            // 
            // btnOrder
            // 
            this.btnOrder.Location = new System.Drawing.Point(18, 259);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(360, 23);
            this.btnOrder.TabIndex = 3;
            this.btnOrder.Text = "주문";
            this.btnOrder.UseVisualStyleBackColor = true;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(18, 288);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(65, 23);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "취소";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnCancelALL
            // 
            this.btnCancelALL.Location = new System.Drawing.Point(89, 288);
            this.btnCancelALL.Name = "btnCancelALL";
            this.btnCancelALL.Size = new System.Drawing.Size(65, 23);
            this.btnCancelALL.TabIndex = 5;
            this.btnCancelALL.Text = "전체취소";
            this.btnCancelALL.UseVisualStyleBackColor = true;
            this.btnCancelALL.Click += new System.EventHandler(this.btnCancelALL_Click);
            // 
            // btnIncreaseQty
            // 
            this.btnIncreaseQty.Location = new System.Drawing.Point(160, 288);
            this.btnIncreaseQty.Name = "btnIncreaseQty";
            this.btnIncreaseQty.Size = new System.Drawing.Size(40, 23);
            this.btnIncreaseQty.TabIndex = 6;
            this.btnIncreaseQty.Text = "+";
            this.btnIncreaseQty.UseVisualStyleBackColor = true;
            this.btnIncreaseQty.Click += new System.EventHandler(this.btnIncreaseQty_Click);
            // 
            // btnDecreaseQty
            // 
            this.btnDecreaseQty.Location = new System.Drawing.Point(206, 288);
            this.btnDecreaseQty.Name = "btnDecreaseQty";
            this.btnDecreaseQty.Size = new System.Drawing.Size(40, 23);
            this.btnDecreaseQty.TabIndex = 7;
            this.btnDecreaseQty.Text = "-";
            this.btnDecreaseQty.UseVisualStyleBackColor = true;
            this.btnDecreaseQty.Click += new System.EventHandler(this.btnDecreaseQty_Click);
            // 
            // lbTotal
            // 
            this.lbTotal.AutoSize = true;
            this.lbTotal.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbTotal.Location = new System.Drawing.Point(252, 288);
            this.lbTotal.Name = "lbTotal";
            this.lbTotal.Size = new System.Drawing.Size(87, 20);
            this.lbTotal.TabIndex = 8;
            this.lbTotal.Text = "전체 금액 : ";
            // 
            // imgSelected
            // 
            this.imgSelected.Location = new System.Drawing.Point(18, 347);
            this.imgSelected.Name = "imgSelected";
            this.imgSelected.Size = new System.Drawing.Size(360, 250);
            this.imgSelected.TabIndex = 9;
            this.imgSelected.TabStop = false;
            // 
            // btnCat_All
            // 
            this.btnCat_All.Location = new System.Drawing.Point(403, 53);
            this.btnCat_All.Name = "btnCat_All";
            this.btnCat_All.Size = new System.Drawing.Size(75, 23);
            this.btnCat_All.TabIndex = 10;
            this.btnCat_All.Text = "전체";
            this.btnCat_All.UseVisualStyleBackColor = true;
            this.btnCat_All.Click += new System.EventHandler(this.CategorySelect);
            // 
            // btnCat_KB
            // 
            this.btnCat_KB.Location = new System.Drawing.Point(484, 53);
            this.btnCat_KB.Name = "btnCat_KB";
            this.btnCat_KB.Size = new System.Drawing.Size(75, 23);
            this.btnCat_KB.TabIndex = 11;
            this.btnCat_KB.Text = "김밥류";
            this.btnCat_KB.UseVisualStyleBackColor = true;
            this.btnCat_KB.Click += new System.EventHandler(this.CategorySelect);
            // 
            // btnCat_Meal
            // 
            this.btnCat_Meal.Location = new System.Drawing.Point(565, 53);
            this.btnCat_Meal.Name = "btnCat_Meal";
            this.btnCat_Meal.Size = new System.Drawing.Size(75, 23);
            this.btnCat_Meal.TabIndex = 12;
            this.btnCat_Meal.Text = "식사류";
            this.btnCat_Meal.UseVisualStyleBackColor = true;
            this.btnCat_Meal.Click += new System.EventHandler(this.CategorySelect);
            // 
            // btnCat_Noodle
            // 
            this.btnCat_Noodle.Location = new System.Drawing.Point(646, 53);
            this.btnCat_Noodle.Name = "btnCat_Noodle";
            this.btnCat_Noodle.Size = new System.Drawing.Size(75, 23);
            this.btnCat_Noodle.TabIndex = 13;
            this.btnCat_Noodle.Text = "면류";
            this.btnCat_Noodle.UseVisualStyleBackColor = true;
            this.btnCat_Noodle.Click += new System.EventHandler(this.CategorySelect);
            // 
            // Radio_Card
            // 
            this.Radio_Card.AutoSize = true;
            this.Radio_Card.Location = new System.Drawing.Point(18, 318);
            this.Radio_Card.Name = "Radio_Card";
            this.Radio_Card.Size = new System.Drawing.Size(47, 16);
            this.Radio_Card.TabIndex = 15;
            this.Radio_Card.TabStop = true;
            this.Radio_Card.Text = "카드";
            this.Radio_Card.UseVisualStyleBackColor = true;
            // 
            // Radio_Cash
            // 
            this.Radio_Cash.AutoSize = true;
            this.Radio_Cash.Location = new System.Drawing.Point(89, 318);
            this.Radio_Cash.Name = "Radio_Cash";
            this.Radio_Cash.Size = new System.Drawing.Size(47, 16);
            this.Radio_Cash.TabIndex = 16;
            this.Radio_Cash.TabStop = true;
            this.Radio_Cash.Text = "현금";
            this.Radio_Cash.UseVisualStyleBackColor = true;
            // 
            // btnPay
            // 
            this.btnPay.Location = new System.Drawing.Point(160, 318);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(218, 23);
            this.btnPay.TabIndex = 17;
            this.btnPay.Text = "결제";
            this.btnPay.UseVisualStyleBackColor = true;
            this.btnPay.Click += new System.EventHandler(this.btnPay_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Location = new System.Drawing.Point(384, 82);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(470, 520);
            this.panel1.TabIndex = 18;
            // 
            // btnCat_Beverage
            // 
            this.btnCat_Beverage.Location = new System.Drawing.Point(727, 53);
            this.btnCat_Beverage.Name = "btnCat_Beverage";
            this.btnCat_Beverage.Size = new System.Drawing.Size(75, 23);
            this.btnCat_Beverage.TabIndex = 19;
            this.btnCat_Beverage.Text = "음료수";
            this.btnCat_Beverage.UseVisualStyleBackColor = true;
            this.btnCat_Beverage.Click += new System.EventHandler(this.CategorySelect);
            // 
            // Table
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.Controls.Add(this.btnCat_Beverage);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnPay);
            this.Controls.Add(this.Radio_Cash);
            this.Controls.Add(this.Radio_Card);
            this.Controls.Add(this.btnCat_Noodle);
            this.Controls.Add(this.btnCat_Meal);
            this.Controls.Add(this.btnCat_KB);
            this.Controls.Add(this.btnCat_All);
            this.Controls.Add(this.imgSelected);
            this.Controls.Add(this.lbTotal);
            this.Controls.Add(this.btnDecreaseQty);
            this.Controls.Add(this.btnIncreaseQty);
            this.Controls.Add(this.btnCancelALL);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOrder);
            this.Controls.Add(this.OrderList);
            this.Controls.Add(this.Label_Time);
            this.Controls.Add(this.TableName);
            this.Name = "Table";
            this.Text = "Table";
            ((System.ComponentModel.ISupportInitialize)(this.imgSelected)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TableName;
        private System.Windows.Forms.Label Label_Time;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnCancelALL;
        private System.Windows.Forms.Button btnIncreaseQty;
        private System.Windows.Forms.Button btnDecreaseQty;
        private System.Windows.Forms.Label lbTotal;
        private System.Windows.Forms.PictureBox imgSelected;
        private System.Windows.Forms.Button btnCat_All;
        private System.Windows.Forms.Button btnCat_KB;
        private System.Windows.Forms.Button btnCat_Meal;
        private System.Windows.Forms.Button btnCat_Noodle;
        private System.Windows.Forms.RadioButton Radio_Card;
        private System.Windows.Forms.RadioButton Radio_Cash;
        private System.Windows.Forms.Button btnPay;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.ListView OrderList;
        private System.Windows.Forms.Button btnCat_Beverage;
    }
}