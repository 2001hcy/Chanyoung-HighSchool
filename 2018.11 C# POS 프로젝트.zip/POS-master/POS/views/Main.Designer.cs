﻿namespace POS
{
    partial class Main
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.Table_1 = new System.Windows.Forms.Button();
            this.Table_5 = new System.Windows.Forms.Button();
            this.Table_2 = new System.Windows.Forms.Button();
            this.Table_6 = new System.Windows.Forms.Button();
            this.Table_3 = new System.Windows.Forms.Button();
            this.Table_4 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label_date = new System.Windows.Forms.Label();
            this.Table_Label1 = new System.Windows.Forms.Label();
            this.Table_Label2 = new System.Windows.Forms.Label();
            this.Table_Label3 = new System.Windows.Forms.Label();
            this.Table_Label4 = new System.Windows.Forms.Label();
            this.Table_Label5 = new System.Windows.Forms.Label();
            this.Table_Label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Table_1
            // 
            this.Table_1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.Table_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table_1.Location = new System.Drawing.Point(10, 68);
            this.Table_1.Name = "Table_1";
            this.Table_1.Size = new System.Drawing.Size(250, 200);
            this.Table_1.TabIndex = 0;
            this.Table_1.UseVisualStyleBackColor = true;
            this.Table_1.Click += new System.EventHandler(this.Table_Click);
            // 
            // Table_5
            // 
            this.Table_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table_5.Location = new System.Drawing.Point(270, 299);
            this.Table_5.Name = "Table_5";
            this.Table_5.Size = new System.Drawing.Size(250, 200);
            this.Table_5.TabIndex = 1;
            this.Table_5.UseVisualStyleBackColor = true;
            this.Table_5.Click += new System.EventHandler(this.Table_Click);
            // 
            // Table_2
            // 
            this.Table_2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.Table_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table_2.Location = new System.Drawing.Point(270, 68);
            this.Table_2.Name = "Table_2";
            this.Table_2.Size = new System.Drawing.Size(250, 200);
            this.Table_2.TabIndex = 2;
            this.Table_2.UseVisualStyleBackColor = true;
            this.Table_2.Click += new System.EventHandler(this.Table_Click);
            // 
            // Table_6
            // 
            this.Table_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table_6.Location = new System.Drawing.Point(530, 299);
            this.Table_6.Name = "Table_6";
            this.Table_6.Size = new System.Drawing.Size(250, 200);
            this.Table_6.TabIndex = 3;
            this.Table_6.UseVisualStyleBackColor = true;
            this.Table_6.Click += new System.EventHandler(this.Table_Click);
            // 
            // Table_3
            // 
            this.Table_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table_3.Location = new System.Drawing.Point(530, 68);
            this.Table_3.Name = "Table_3";
            this.Table_3.Size = new System.Drawing.Size(250, 200);
            this.Table_3.TabIndex = 4;
            this.Table_3.UseVisualStyleBackColor = true;
            this.Table_3.Click += new System.EventHandler(this.Table_Click);
            // 
            // Table_4
            // 
            this.Table_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table_4.Location = new System.Drawing.Point(10, 299);
            this.Table_4.Name = "Table_4";
            this.Table_4.Size = new System.Drawing.Size(248, 200);
            this.Table_4.TabIndex = 5;
            this.Table_4.UseVisualStyleBackColor = true;
            this.Table_4.Click += new System.EventHandler(this.Table_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(13, 13);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 6;
            this.button7.Text = "통계";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label_date
            // 
            this.label_date.AutoSize = true;
            this.label_date.Font = new System.Drawing.Font("맑은 고딕", 16F);
            this.label_date.Location = new System.Drawing.Point(372, 6);
            this.label_date.Name = "label_date";
            this.label_date.Size = new System.Drawing.Size(101, 30);
            this.label_date.TabIndex = 8;
            this.label_date.Text = "현재시간";
            // 
            // Table_Label1
            // 
            this.Table_Label1.AutoSize = true;
            this.Table_Label1.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Table_Label1.Location = new System.Drawing.Point(15, 40);
            this.Table_Label1.Name = "Table_Label1";
            this.Table_Label1.Size = new System.Drawing.Size(106, 25);
            this.Table_Label1.TabIndex = 9;
            this.Table_Label1.Text = "1번 테이블";
            // 
            // Table_Label2
            // 
            this.Table_Label2.AutoSize = true;
            this.Table_Label2.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Table_Label2.Location = new System.Drawing.Point(277, 40);
            this.Table_Label2.Name = "Table_Label2";
            this.Table_Label2.Size = new System.Drawing.Size(106, 25);
            this.Table_Label2.TabIndex = 10;
            this.Table_Label2.Text = "2번 테이블";
            // 
            // Table_Label3
            // 
            this.Table_Label3.AutoSize = true;
            this.Table_Label3.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Table_Label3.Location = new System.Drawing.Point(535, 40);
            this.Table_Label3.Name = "Table_Label3";
            this.Table_Label3.Size = new System.Drawing.Size(106, 25);
            this.Table_Label3.TabIndex = 11;
            this.Table_Label3.Text = "3번 테이블";
            // 
            // Table_Label4
            // 
            this.Table_Label4.AutoSize = true;
            this.Table_Label4.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Table_Label4.Location = new System.Drawing.Point(15, 271);
            this.Table_Label4.Name = "Table_Label4";
            this.Table_Label4.Size = new System.Drawing.Size(106, 25);
            this.Table_Label4.TabIndex = 12;
            this.Table_Label4.Text = "4번 테이블";
            // 
            // Table_Label5
            // 
            this.Table_Label5.AutoSize = true;
            this.Table_Label5.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Table_Label5.Location = new System.Drawing.Point(277, 271);
            this.Table_Label5.Name = "Table_Label5";
            this.Table_Label5.Size = new System.Drawing.Size(106, 25);
            this.Table_Label5.TabIndex = 13;
            this.Table_Label5.Text = "5번 테이블";
            // 
            // Table_Label6
            // 
            this.Table_Label6.AutoSize = true;
            this.Table_Label6.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Table_Label6.Location = new System.Drawing.Point(535, 271);
            this.Table_Label6.Name = "Table_Label6";
            this.Table_Label6.Size = new System.Drawing.Size(106, 25);
            this.Table_Label6.TabIndex = 14;
            this.Table_Label6.Text = "6번 테이블";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 511);
            this.Controls.Add(this.Table_Label6);
            this.Controls.Add(this.Table_Label5);
            this.Controls.Add(this.Table_Label4);
            this.Controls.Add(this.Table_Label3);
            this.Controls.Add(this.Table_Label2);
            this.Controls.Add(this.Table_Label1);
            this.Controls.Add(this.label_date);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.Table_4);
            this.Controls.Add(this.Table_3);
            this.Controls.Add(this.Table_6);
            this.Controls.Add(this.Table_2);
            this.Controls.Add(this.Table_5);
            this.Controls.Add(this.Table_1);
            this.Name = "Main";
            this.Text = "Main";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Table_1;
        private System.Windows.Forms.Button Table_5;
        private System.Windows.Forms.Button Table_2;
        private System.Windows.Forms.Button Table_6;
        private System.Windows.Forms.Button Table_3;
        private System.Windows.Forms.Button Table_4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label_date;
        private System.Windows.Forms.Label Table_Label1;
        private System.Windows.Forms.Label Table_Label2;
        private System.Windows.Forms.Label Table_Label3;
        private System.Windows.Forms.Label Table_Label4;
        private System.Windows.Forms.Label Table_Label5;
        private System.Windows.Forms.Label Table_Label6;
    }
}

