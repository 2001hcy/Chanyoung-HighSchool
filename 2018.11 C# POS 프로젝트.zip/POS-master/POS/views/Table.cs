﻿using POS.classes;
using System;
using System.Drawing;
using System.Windows.Forms;
using static POS.Main;

namespace POS
{
    partial class Table : Form
    {
        private _Table self;
        Categories Form = new Categories();
        public delegate void OrderEventHandler(object sender, EventHandler e, int tablenum);
        public event OrderEventHandler Order;
        private string barcodeString = string.Empty;

        public Table(_Table table)
        {
            InitializeComponent();
            panel1.Controls.Add(Form.Category_ALL); //[전체] 카테고리를 기본으로 불러옴 
            TableName.Text = table.tablenum.ToString()+ "번 테이블 "; //테이블 번호를 표기
            Time.Load();    Time.Set();     
            Label_Time.Text = "주문시간:" + Time.TIME;  //주문당시 시간을 라벨에 표기, List에 저장
            table.Ordertime=Time.time;  
            Form.Menu_Select += Menu_Select;
            self = table;
            ReloadList();
            
        }

        private void Menu_Select(object sender, EventHandler e,string menu)
        {
            foreach(Menu food in lstTable[self.tablenum].listMenu)
            {
                if (food.name == menu)
                {
                    if (food.count > 0)
                    {
                        MessageBox.Show("이미 추가된 상품입니다");
                        break;
                    }
                    food.count++;
                    ReloadList();
                    ListSelectInit();
                    OrderList.Items[OrderList.Items.Count - 1].Selected = true;
                }
            }
            return;
        }

        private void CategorySelect(object sender, EventArgs e)
        {
            Control value;
            Button button = (Button)sender;
            string Category = button.Name;
            switch (Category)
            {
                case "btnCat_KB": value = Form.Category_KB; break;
                case "btnCat_Meal": value = Form.Category_Meal; break;
                case "btnCat_Noodle": value = Form.Category_Noodle; break;
                case "btnCat_Beverage": value = Form.Category_Beverage; break;
                default: value = Form.Category_ALL; break;
            }
            panel1.Controls.Clear();
            panel1.Controls.Add(value);

        }

        #region 수량 증가,감소 버튼
        private void btnIncreaseQty_Click(object sender, EventArgs e)   //수량 추가
        {
            for (int i = 0; i < OrderList.Items.Count; i++)
            {
                if (OrderList.Items[i].Selected == true)
                {
                
                    foreach (Menu food in lstTable[self.tablenum].listMenu)
                    {
                        if (food.name == OrderList.Items[i].Text)
                        {
                            food.count++;
                            ReloadList();
                        }
                    }
                }
            }
        }

        private void btnDecreaseQty_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < OrderList.Items.Count; i++)
            {
                if (OrderList.Items[i].Selected == true)
                {
                    foreach (Menu food in lstTable[self.tablenum].listMenu)
                    {
                        if (food.name == OrderList.Items[i].Text)
                        {
                            food.count--;
                            if(food.count == 0)
                            {
                                OrderList.Items[i].Remove();
                                return;
                            }
                            ReloadList();
                        }
                    }
                }
            }
        }
        #endregion

        private void btnOrder_Click(object sender, EventArgs e)
        {
            Order.Invoke(this, null,self.tablenum);
            Close();
        }

        void ReloadList()   //주문 리스트 화면 갱신해주는 함수
        {
            int temp = 0; int total = 0; // 현재 선택된 항목 번호와 주문 총액 저장하는 변수. 
            int test = self.tablenum;
            for (int i = 0; i < OrderList.Items.Count; i++)   //현재 선택된 항목이 없으면 -1이 그대로 남아있을 것.
            {
                if(OrderList.Items[i].Selected == true)
                {
                    temp = i;
                }
            }
            OrderList.Items.Clear();         //ListView 초기화 
            foreach (Menu food in lstTable[self.tablenum].listMenu)
            {
                if (food.count > 0) //1개 이상 카운트된 항목들을 ListView에 추가
                {
                    total += (food.price * food.count);
                    string[] str = { food.name, food.count.ToString(), (food.price * food.count).ToString() };
                    ListViewItem data = new ListViewItem(str);
                    OrderList.Items.Add(data);
                }
            }
            lbTotal.Text = "전체 금액 : " + total.ToString();  
            if (temp == OrderList.Items.Count) return; // 기존에 추가(선택) 한 항목이 있는지 검사. 없으면 return 해야함(안하면 밑에서 오류남)
            OrderList.Items[temp].Selected = true;  //  
        }

        void ListSelectInit()
        {
            for (int i = 0; i < OrderList.Items.Count; i++)
            {
                OrderList.Items[i].Selected = false;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < OrderList.Items.Count; i++)
            {
                if (OrderList.Items[i].Selected == true)
                {
                    foreach (Menu food in lstTable[self.tablenum].listMenu)
                    {
                        if (food.name == OrderList.Items[i].Text)
                        {
                            food.count = 0;
                            OrderList.Items[i].Remove();
                            return;
                        }
                    }
                }
            }
        }
        private void btnCancelALL_Click(object sender, EventArgs e)
        {
            OrderList.Items.Clear();
            foreach (Menu food in lstTable[self.tablenum].listMenu)
            {
                if (food.count > 0)
                {
                    food.count = 0;
                }
            }
            imgSelected.Image = null;
        }
        private void OrderList_SelectedIndexChanged(object sender, EventArgs e)
        {
            for(int i = 0;i < OrderList.Items.Count; i++)
            {
                if (OrderList.Items[i].Selected == true)
                {
                    foreach(Menu food in self.listMenu)
                    {
                        if(OrderList.Items[i].Text == food.name)
                        {
                            imgSelected.Image = Image.FromFile(food.imgPath);
                        }
                    }
                }
            }
        }
        private void btnPay_Click(object sender, EventArgs e)
        {
            if (OrderList.Items.Count == 0) return;
            string message = "";
            int total = 0;
            if (!(Radio_Card.Checked || Radio_Cash.Checked))
            {
                MessageBox.Show("결제 방법을 선택해 주십시오", "알림");
                return;
            }
            for (int i = 0; i < OrderList.Items.Count; i++)
            {
                message += OrderList.Items[i].Text+" 수량 : "+OrderList.Items[i].SubItems[1].Text+"\n";
                total += int.Parse(OrderList.Items[i].SubItems[2].Text);
                foreach (History history in history)
                {
                    if(history.name == OrderList.Items[i].Text)
                    {
                        history.count += int.Parse(OrderList.Items[i].SubItems[1].Text);
                    }
                }
            }
            message += "총금액 : " + total.ToString();
            
            if (Radio_Card.Checked) message += "(카드결제)";
            if (Radio_Cash.Checked) message += "(현금결제)";
            DialogResult dr = MessageBox.Show(message, "결제확인", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (dr == DialogResult.OK)
            {
                MessageBox.Show("결제 완료 되었습니다.");
                foreach(Menu food in self.listMenu) food.count = 0;
                for (int i = (OrderList.Items.Count)-1; i >= 0; i--) OrderList.Items[i].Remove();
                Order.Invoke(this, null, self.tablenum);
            }

        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            ActiveControl = null;
            string menu = "";
            if (msg.Msg == 0x100)
            {
                if (barcodeString.Equals("8801094017200"))
                {
                    Console.WriteLine(barcodeString);
                    menu = "코카콜라";
                }
                else if (barcodeString.Equals("8801056070809"))
                {
                    Console.WriteLine(barcodeString);
                    menu = "펩시";
                }
                else
                {
                    barcodeString += char.ConvertFromUtf32((int)keyData);
                }
                foreach (Menu food in lstTable[self.tablenum].listMenu)
                {
                    if (food.name == menu)
                    {
                        if (food.count > 0)
                        {
                            MessageBox.Show("이미 추가된 상품입니다");
                            barcodeString = string.Empty;
                            break;
                        }
                        food.count++;
                        ReloadList();
                        ListSelectInit();
                        barcodeString = string.Empty;
                    }
                }
                return false;
            }
            return false;
        }

    }
}
