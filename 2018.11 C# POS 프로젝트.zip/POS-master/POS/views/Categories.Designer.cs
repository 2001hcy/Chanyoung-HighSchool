﻿namespace POS
{
    partial class Categories
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Category_ALL = new System.Windows.Forms.FlowLayoutPanel();
            this.Category_KB = new System.Windows.Forms.FlowLayoutPanel();
            this.Category_Noodle = new System.Windows.Forms.FlowLayoutPanel();
            this.Category_Meal = new System.Windows.Forms.FlowLayoutPanel();
            this.Category_Beverage = new System.Windows.Forms.FlowLayoutPanel();
            this.CbtnKB = new System.Windows.Forms.Button();
            this.CbtnTKB = new System.Windows.Forms.Button();
            this.CbtnDKB = new System.Windows.Forms.Button();
            this.btnKB = new System.Windows.Forms.Button();
            this.btnTKB = new System.Windows.Forms.Button();
            this.btnDKB = new System.Windows.Forms.Button();
            this.btnRamen = new System.Windows.Forms.Button();
            this.btnUdon = new System.Windows.Forms.Button();
            this.btnNoodle = new System.Windows.Forms.Button();
            this.btnBBB = new System.Windows.Forms.Button();
            this.btnTofu = new System.Windows.Forms.Button();
            this.btnCurry = new System.Windows.Forms.Button();
            this.CbtnBBB = new System.Windows.Forms.Button();
            this.CbtnTofu = new System.Windows.Forms.Button();
            this.CbtnCurry = new System.Windows.Forms.Button();
            this.CbtnPepsi = new System.Windows.Forms.Button();
            this.CbtnCoke = new System.Windows.Forms.Button();
            this.CbtnRamen = new System.Windows.Forms.Button();
            this.CbtnUdon = new System.Windows.Forms.Button();
            this.CbtnNoodle = new System.Windows.Forms.Button();
            this.btnPepsi = new System.Windows.Forms.Button();
            this.btnCoke = new System.Windows.Forms.Button();
            this.Category_ALL.SuspendLayout();
            this.Category_KB.SuspendLayout();
            this.Category_Noodle.SuspendLayout();
            this.Category_Meal.SuspendLayout();
            this.Category_Beverage.SuspendLayout();
            this.SuspendLayout();
            // 
            // Category_ALL
            // 
            this.Category_ALL.AutoScroll = true;
            this.Category_ALL.Controls.Add(this.btnKB);
            this.Category_ALL.Controls.Add(this.btnTKB);
            this.Category_ALL.Controls.Add(this.btnDKB);
            this.Category_ALL.Controls.Add(this.btnRamen);
            this.Category_ALL.Controls.Add(this.btnUdon);
            this.Category_ALL.Controls.Add(this.btnNoodle);
            this.Category_ALL.Controls.Add(this.btnBBB);
            this.Category_ALL.Controls.Add(this.btnTofu);
            this.Category_ALL.Controls.Add(this.btnCurry);
            this.Category_ALL.Controls.Add(this.btnPepsi);
            this.Category_ALL.Controls.Add(this.btnCoke);
            this.Category_ALL.Location = new System.Drawing.Point(20, 20);
            this.Category_ALL.Name = "Category_ALL";
            this.Category_ALL.Size = new System.Drawing.Size(493, 511);
            this.Category_ALL.TabIndex = 0;
            // 
            // Category_KB
            // 
            this.Category_KB.AutoScroll = true;
            this.Category_KB.Controls.Add(this.CbtnKB);
            this.Category_KB.Controls.Add(this.CbtnTKB);
            this.Category_KB.Controls.Add(this.CbtnDKB);
            this.Category_KB.Location = new System.Drawing.Point(20, 20);
            this.Category_KB.Margin = new System.Windows.Forms.Padding(0);
            this.Category_KB.Name = "Category_KB";
            this.Category_KB.Size = new System.Drawing.Size(493, 511);
            this.Category_KB.TabIndex = 0;
            // 
            // Category_Noodle
            // 
            this.Category_Noodle.AutoScroll = true;
            this.Category_Noodle.Controls.Add(this.CbtnRamen);
            this.Category_Noodle.Controls.Add(this.CbtnUdon);
            this.Category_Noodle.Controls.Add(this.CbtnNoodle);
            this.Category_Noodle.Location = new System.Drawing.Point(20, 20);
            this.Category_Noodle.Margin = new System.Windows.Forms.Padding(0);
            this.Category_Noodle.Name = "Category_Noodle";
            this.Category_Noodle.Size = new System.Drawing.Size(493, 511);
            this.Category_Noodle.TabIndex = 0;
            // 
            // Category_Meal
            // 
            this.Category_Meal.AutoScroll = true;
            this.Category_Meal.Controls.Add(this.CbtnBBB);
            this.Category_Meal.Controls.Add(this.CbtnTofu);
            this.Category_Meal.Controls.Add(this.CbtnCurry);
            this.Category_Meal.Location = new System.Drawing.Point(20, 20);
            this.Category_Meal.Name = "Category_Meal";
            this.Category_Meal.Size = new System.Drawing.Size(493, 511);
            this.Category_Meal.TabIndex = 0;
            // 
            // Category_Beverage
            // 
            this.Category_Beverage.AutoScroll = true;
            this.Category_Beverage.Controls.Add(this.CbtnPepsi);
            this.Category_Beverage.Controls.Add(this.CbtnCoke);
            this.Category_Beverage.Location = new System.Drawing.Point(20, 20);
            this.Category_Beverage.Margin = new System.Windows.Forms.Padding(0);
            this.Category_Beverage.Name = "Category_Beverage";
            this.Category_Beverage.Size = new System.Drawing.Size(493, 511);
            this.Category_Beverage.TabIndex = 3;
            // 
            // CbtnKB
            // 
            this.CbtnKB.BackgroundImage = global::POS.Properties.Resources.김밥;
            this.CbtnKB.FlatAppearance.BorderSize = 0;
            this.CbtnKB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbtnKB.Location = new System.Drawing.Point(5, 5);
            this.CbtnKB.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.CbtnKB.Name = "CbtnKB";
            this.CbtnKB.Size = new System.Drawing.Size(225, 225);
            this.CbtnKB.TabIndex = 0;
            this.CbtnKB.UseVisualStyleBackColor = true;
            this.CbtnKB.Click += new System.EventHandler(this.MenuSelect);
            // 
            // CbtnTKB
            // 
            this.CbtnTKB.BackgroundImage = global::POS.Properties.Resources.참치김밥;
            this.CbtnTKB.FlatAppearance.BorderSize = 0;
            this.CbtnTKB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbtnTKB.Location = new System.Drawing.Point(238, 5);
            this.CbtnTKB.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.CbtnTKB.Name = "CbtnTKB";
            this.CbtnTKB.Size = new System.Drawing.Size(225, 225);
            this.CbtnTKB.TabIndex = 1;
            this.CbtnTKB.UseVisualStyleBackColor = true;
            this.CbtnTKB.Click += new System.EventHandler(this.MenuSelect);
            // 
            // CbtnDKB
            // 
            this.CbtnDKB.BackgroundImage = global::POS.Properties.Resources.돈까스김밥;
            this.CbtnDKB.FlatAppearance.BorderSize = 0;
            this.CbtnDKB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbtnDKB.Location = new System.Drawing.Point(5, 238);
            this.CbtnDKB.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.CbtnDKB.Name = "CbtnDKB";
            this.CbtnDKB.Size = new System.Drawing.Size(225, 225);
            this.CbtnDKB.TabIndex = 2;
            this.CbtnDKB.UseVisualStyleBackColor = true;
            this.CbtnDKB.Click += new System.EventHandler(this.MenuSelect);
            // 
            // btnKB
            // 
            this.btnKB.BackgroundImage = global::POS.Properties.Resources.김밥;
            this.btnKB.FlatAppearance.BorderSize = 0;
            this.btnKB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKB.Font = new System.Drawing.Font("굴림", 10F);
            this.btnKB.ForeColor = System.Drawing.Color.Transparent;
            this.btnKB.Location = new System.Drawing.Point(5, 5);
            this.btnKB.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.btnKB.Name = "btnKB";
            this.btnKB.Size = new System.Drawing.Size(225, 225);
            this.btnKB.TabIndex = 0;
            this.btnKB.Text = "김밥";
            this.btnKB.UseVisualStyleBackColor = true;
            this.btnKB.Click += new System.EventHandler(this.MenuSelect);
            // 
            // btnTKB
            // 
            this.btnTKB.BackgroundImage = global::POS.Properties.Resources.참치김밥;
            this.btnTKB.FlatAppearance.BorderSize = 0;
            this.btnTKB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTKB.Location = new System.Drawing.Point(238, 5);
            this.btnTKB.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.btnTKB.Name = "btnTKB";
            this.btnTKB.Size = new System.Drawing.Size(225, 225);
            this.btnTKB.TabIndex = 1;
            this.btnTKB.UseVisualStyleBackColor = true;
            this.btnTKB.Click += new System.EventHandler(this.MenuSelect);
            // 
            // btnDKB
            // 
            this.btnDKB.BackgroundImage = global::POS.Properties.Resources.돈까스김밥;
            this.btnDKB.FlatAppearance.BorderSize = 0;
            this.btnDKB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDKB.Location = new System.Drawing.Point(5, 238);
            this.btnDKB.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.btnDKB.Name = "btnDKB";
            this.btnDKB.Size = new System.Drawing.Size(225, 225);
            this.btnDKB.TabIndex = 2;
            this.btnDKB.UseVisualStyleBackColor = true;
            this.btnDKB.Click += new System.EventHandler(this.MenuSelect);
            // 
            // btnRamen
            // 
            this.btnRamen.BackgroundImage = global::POS.Properties.Resources.라면;
            this.btnRamen.FlatAppearance.BorderSize = 0;
            this.btnRamen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRamen.Location = new System.Drawing.Point(238, 238);
            this.btnRamen.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.btnRamen.Name = "btnRamen";
            this.btnRamen.Size = new System.Drawing.Size(225, 225);
            this.btnRamen.TabIndex = 3;
            this.btnRamen.UseVisualStyleBackColor = true;
            this.btnRamen.Click += new System.EventHandler(this.MenuSelect);
            // 
            // btnUdon
            // 
            this.btnUdon.BackgroundImage = global::POS.Properties.Resources.우동;
            this.btnUdon.FlatAppearance.BorderSize = 0;
            this.btnUdon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUdon.Location = new System.Drawing.Point(5, 471);
            this.btnUdon.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.btnUdon.Name = "btnUdon";
            this.btnUdon.Size = new System.Drawing.Size(225, 225);
            this.btnUdon.TabIndex = 4;
            this.btnUdon.UseVisualStyleBackColor = true;
            this.btnUdon.Click += new System.EventHandler(this.MenuSelect);
            // 
            // btnNoodle
            // 
            this.btnNoodle.BackgroundImage = global::POS.Properties.Resources.잔치국수;
            this.btnNoodle.FlatAppearance.BorderSize = 0;
            this.btnNoodle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNoodle.Location = new System.Drawing.Point(238, 471);
            this.btnNoodle.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.btnNoodle.Name = "btnNoodle";
            this.btnNoodle.Size = new System.Drawing.Size(225, 225);
            this.btnNoodle.TabIndex = 5;
            this.btnNoodle.UseVisualStyleBackColor = true;
            this.btnNoodle.Click += new System.EventHandler(this.MenuSelect);
            // 
            // btnBBB
            // 
            this.btnBBB.BackgroundImage = global::POS.Properties.Resources.비빔밥;
            this.btnBBB.FlatAppearance.BorderSize = 0;
            this.btnBBB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBBB.Location = new System.Drawing.Point(5, 704);
            this.btnBBB.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.btnBBB.Name = "btnBBB";
            this.btnBBB.Size = new System.Drawing.Size(225, 225);
            this.btnBBB.TabIndex = 6;
            this.btnBBB.UseVisualStyleBackColor = true;
            this.btnBBB.Click += new System.EventHandler(this.MenuSelect);
            // 
            // btnTofu
            // 
            this.btnTofu.BackgroundImage = global::POS.Properties.Resources.순두부찌개;
            this.btnTofu.FlatAppearance.BorderSize = 0;
            this.btnTofu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTofu.Location = new System.Drawing.Point(238, 704);
            this.btnTofu.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.btnTofu.Name = "btnTofu";
            this.btnTofu.Size = new System.Drawing.Size(225, 225);
            this.btnTofu.TabIndex = 7;
            this.btnTofu.UseVisualStyleBackColor = true;
            this.btnTofu.Click += new System.EventHandler(this.MenuSelect);
            // 
            // btnCurry
            // 
            this.btnCurry.BackgroundImage = global::POS.Properties.Resources.카레라이스;
            this.btnCurry.FlatAppearance.BorderSize = 0;
            this.btnCurry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCurry.Location = new System.Drawing.Point(5, 937);
            this.btnCurry.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.btnCurry.Name = "btnCurry";
            this.btnCurry.Size = new System.Drawing.Size(225, 225);
            this.btnCurry.TabIndex = 8;
            this.btnCurry.UseVisualStyleBackColor = true;
            this.btnCurry.Click += new System.EventHandler(this.MenuSelect);
            // 
            // CbtnBBB
            // 
            this.CbtnBBB.BackgroundImage = global::POS.Properties.Resources.비빔밥;
            this.CbtnBBB.FlatAppearance.BorderSize = 0;
            this.CbtnBBB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbtnBBB.Location = new System.Drawing.Point(5, 5);
            this.CbtnBBB.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.CbtnBBB.Name = "CbtnBBB";
            this.CbtnBBB.Size = new System.Drawing.Size(225, 225);
            this.CbtnBBB.TabIndex = 6;
            this.CbtnBBB.UseVisualStyleBackColor = true;
            this.CbtnBBB.Click += new System.EventHandler(this.MenuSelect);
            // 
            // CbtnTofu
            // 
            this.CbtnTofu.BackgroundImage = global::POS.Properties.Resources.순두부찌개;
            this.CbtnTofu.FlatAppearance.BorderSize = 0;
            this.CbtnTofu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbtnTofu.Location = new System.Drawing.Point(238, 5);
            this.CbtnTofu.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.CbtnTofu.Name = "CbtnTofu";
            this.CbtnTofu.Size = new System.Drawing.Size(225, 225);
            this.CbtnTofu.TabIndex = 7;
            this.CbtnTofu.UseVisualStyleBackColor = true;
            this.CbtnTofu.Click += new System.EventHandler(this.MenuSelect);
            // 
            // CbtnCurry
            // 
            this.CbtnCurry.BackgroundImage = global::POS.Properties.Resources.카레라이스;
            this.CbtnCurry.FlatAppearance.BorderSize = 0;
            this.CbtnCurry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbtnCurry.Location = new System.Drawing.Point(5, 238);
            this.CbtnCurry.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.CbtnCurry.Name = "CbtnCurry";
            this.CbtnCurry.Size = new System.Drawing.Size(225, 225);
            this.CbtnCurry.TabIndex = 8;
            this.CbtnCurry.UseVisualStyleBackColor = true;
            this.CbtnCurry.Click += new System.EventHandler(this.MenuSelect);
            // 
            // CbtnPepsi
            // 
            this.CbtnPepsi.BackgroundImage = global::POS.Properties.Resources.펩시;
            this.CbtnPepsi.FlatAppearance.BorderSize = 0;
            this.CbtnPepsi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbtnPepsi.Location = new System.Drawing.Point(5, 5);
            this.CbtnPepsi.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.CbtnPepsi.Name = "CbtnPepsi";
            this.CbtnPepsi.Size = new System.Drawing.Size(225, 225);
            this.CbtnPepsi.TabIndex = 0;
            this.CbtnPepsi.UseVisualStyleBackColor = true;
            this.CbtnPepsi.Click += new System.EventHandler(this.MenuSelect);
            // 
            // CbtnCoke
            // 
            this.CbtnCoke.BackgroundImage = global::POS.Properties.Resources.코카콜라;
            this.CbtnCoke.FlatAppearance.BorderSize = 0;
            this.CbtnCoke.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbtnCoke.Location = new System.Drawing.Point(238, 5);
            this.CbtnCoke.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.CbtnCoke.Name = "CbtnCoke";
            this.CbtnCoke.Size = new System.Drawing.Size(225, 225);
            this.CbtnCoke.TabIndex = 1;
            this.CbtnCoke.UseVisualStyleBackColor = true;
            this.CbtnCoke.Click += new System.EventHandler(this.MenuSelect);
            // 
            // CbtnRamen
            // 
            this.CbtnRamen.BackgroundImage = global::POS.Properties.Resources.라면;
            this.CbtnRamen.FlatAppearance.BorderSize = 0;
            this.CbtnRamen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbtnRamen.Location = new System.Drawing.Point(5, 5);
            this.CbtnRamen.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.CbtnRamen.Name = "CbtnRamen";
            this.CbtnRamen.Size = new System.Drawing.Size(225, 225);
            this.CbtnRamen.TabIndex = 3;
            this.CbtnRamen.UseVisualStyleBackColor = true;
            this.CbtnRamen.Click += new System.EventHandler(this.MenuSelect);
            // 
            // CbtnUdon
            // 
            this.CbtnUdon.BackgroundImage = global::POS.Properties.Resources.우동;
            this.CbtnUdon.FlatAppearance.BorderSize = 0;
            this.CbtnUdon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbtnUdon.Location = new System.Drawing.Point(238, 5);
            this.CbtnUdon.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.CbtnUdon.Name = "CbtnUdon";
            this.CbtnUdon.Size = new System.Drawing.Size(225, 225);
            this.CbtnUdon.TabIndex = 4;
            this.CbtnUdon.UseVisualStyleBackColor = true;
            this.CbtnUdon.Click += new System.EventHandler(this.MenuSelect);
            // 
            // CbtnNoodle
            // 
            this.CbtnNoodle.BackgroundImage = global::POS.Properties.Resources.잔치국수;
            this.CbtnNoodle.FlatAppearance.BorderSize = 0;
            this.CbtnNoodle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbtnNoodle.Location = new System.Drawing.Point(5, 238);
            this.CbtnNoodle.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.CbtnNoodle.Name = "CbtnNoodle";
            this.CbtnNoodle.Size = new System.Drawing.Size(225, 225);
            this.CbtnNoodle.TabIndex = 5;
            this.CbtnNoodle.UseVisualStyleBackColor = true;
            this.CbtnNoodle.Click += new System.EventHandler(this.MenuSelect);
            // 
            // btnPepsi
            // 
            this.btnPepsi.BackgroundImage = global::POS.Properties.Resources.펩시;
            this.btnPepsi.FlatAppearance.BorderSize = 0;
            this.btnPepsi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPepsi.Location = new System.Drawing.Point(238, 937);
            this.btnPepsi.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.btnPepsi.Name = "btnPepsi";
            this.btnPepsi.Size = new System.Drawing.Size(225, 225);
            this.btnPepsi.TabIndex = 9;
            this.btnPepsi.UseVisualStyleBackColor = true;
            this.btnPepsi.Click += new System.EventHandler(this.MenuSelect);
            // 
            // btnCoke
            // 
            this.btnCoke.BackgroundImage = global::POS.Properties.Resources.코카콜라;
            this.btnCoke.FlatAppearance.BorderSize = 0;
            this.btnCoke.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCoke.Location = new System.Drawing.Point(5, 1170);
            this.btnCoke.Margin = new System.Windows.Forms.Padding(5, 5, 3, 3);
            this.btnCoke.Name = "btnCoke";
            this.btnCoke.Size = new System.Drawing.Size(225, 225);
            this.btnCoke.TabIndex = 10;
            this.btnCoke.UseVisualStyleBackColor = true;
            this.btnCoke.Click += new System.EventHandler(this.MenuSelect);
            // 
            // Categories
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1940, 600);
            this.Controls.Add(this.Category_Beverage);
            this.Controls.Add(this.Category_Noodle);
            this.Controls.Add(this.Category_KB);
            this.Controls.Add(this.Category_ALL);
            this.Controls.Add(this.Category_Meal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Categories";
            this.Category_ALL.ResumeLayout(false);
            this.Category_KB.ResumeLayout(false);
            this.Category_Noodle.ResumeLayout(false);
            this.Category_Meal.ResumeLayout(false);
            this.Category_Beverage.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnKB;
        private System.Windows.Forms.Button btnTKB;
        private System.Windows.Forms.Button btnDKB;
        private System.Windows.Forms.Button btnRamen;
        private System.Windows.Forms.Button btnUdon;
        private System.Windows.Forms.Button btnNoodle;
        private System.Windows.Forms.Button btnBBB;
        private System.Windows.Forms.Button btnTofu;
        private System.Windows.Forms.Button btnCurry;
        public System.Windows.Forms.FlowLayoutPanel Category_ALL;
        public System.Windows.Forms.FlowLayoutPanel Category_KB;
        private System.Windows.Forms.Button CbtnKB;
        private System.Windows.Forms.Button CbtnTKB;
        private System.Windows.Forms.Button CbtnDKB;
        public System.Windows.Forms.FlowLayoutPanel Category_Noodle;
        private System.Windows.Forms.Button CbtnRamen;
        private System.Windows.Forms.Button CbtnUdon;
        private System.Windows.Forms.Button CbtnNoodle;
        public System.Windows.Forms.FlowLayoutPanel Category_Meal;
        private System.Windows.Forms.Button CbtnBBB;
        private System.Windows.Forms.Button CbtnTofu;
        private System.Windows.Forms.Button CbtnCurry;
        public System.Windows.Forms.FlowLayoutPanel Category_Beverage;
        private System.Windows.Forms.Button CbtnPepsi;
        private System.Windows.Forms.Button CbtnCoke;
        private System.Windows.Forms.Button btnPepsi;
        private System.Windows.Forms.Button btnCoke;
    }
}