﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using POS.classes;
using POS.views;

namespace POS
{
    public partial class Main : Form
    {
        public static List<Menu> lstMenu = new List<Menu>();
        public static List<_Table> lstTable = new List<_Table>();
        public static List<History> history = new List<History>();
        Timer timer = new Timer();
        public Main()
        {
            InitializeComponent();
            ListInit();
            Loading intro = new Loading();
            intro.Show();
            intro.FormClosed += Intro_FormClosed;
            timer.Tick += timer_Tick;
            timer_Tick(null, null);
            timer.Interval = 1000;
            this.Opacity = 0;
            timer.Start();
        }
        

        private void Intro_FormClosed(object sender, FormClosedEventArgs e)
        {
            Opacity = 100;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            Time.Load();
            Time.Set();
            label_date.Text = "현재시간:" + Time.TIME;
        }
        private void Table_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string TableName = button.Name;
            int tablenum = 0;
            switch (TableName)      //몇 번 테이블을 눌렀는지 판단해서 tablenum 변수에 정수로 저장, Table 창을 열 때 전달함
            {
                case "Table_1": tablenum = 1; break;
                case "Table_2": tablenum = 2; break;
                case "Table_3": tablenum = 3; break;
                case "Table_4": tablenum = 4; break;
                case "Table_5": tablenum = 5; break;
                case "Table_6": tablenum = 6; break;
            }
            Table table = new Table(lstTable[tablenum]);
            table.Order += Order;
            table.Show();
        }
        private void ListInit()
        {
            lstTable.Add(new _Table()); //Index 를 1부터 주기 위해서 0 Index의 테이블을 하나 생성 
            for (int i = 1; i <= 6; i++)
            {
                lstTable.Add(new _Table() { tablenum = i, listMenu = new List<Menu>()});
                lstTable[i].listMenu.Add(new Menu("김밥", 2000, "김밥류", "C:\\Users\\Jaws\\Desktop\\Develop\\C#\\POS\\POS\\img\\김밥.png"));
                lstTable[i].listMenu.Add(new Menu("참치김밥", 3000, "김밥류", "C:\\Users\\Jaws\\Desktop\\Develop\\C#\\POS\\POS\\img\\참치김밥.png"));
                lstTable[i].listMenu.Add(new Menu("돈까스김밥", 4000, "김밥류", "C:\\Users\\Jaws\\Desktop\\Develop\\C#\\POS\\POS\\img\\돈까스김밥.png"));
                lstTable[i].listMenu.Add(new Menu("라면", 3000, "면류", "C:\\Users\\Jaws\\Desktop\\Develop\\C#\\POS\\POS\\img\\라면.png"));
                lstTable[i].listMenu.Add(new Menu("우동", 4000, "면류", "C:\\Users\\Jaws\\Desktop\\Develop\\C#\\POS\\POS\\img\\우동.png"));
                lstTable[i].listMenu.Add(new Menu("잔치국수", 5000, "면류", "C:\\Users\\Jaws\\Desktop\\Develop\\C#\\POS\\POS\\img\\잔치국수.png"));
                lstTable[i].listMenu.Add(new Menu("비빔밥", 5000, "식사류", "C:\\Users\\Jaws\\Desktop\\Develop\\C#\\POS\\POS\\img\\비빔밥.png"));
                lstTable[i].listMenu.Add(new Menu("순두부찌개", 6000, "식사류", "C:\\Users\\Jaws\\Desktop\\Develop\\C#\\POS\\POS\\img\\순두부찌개.png"));
                lstTable[i].listMenu.Add(new Menu("카레라이스", 7000, "식사류", "C:\\Users\\Jaws\\Desktop\\Develop\\C#\\POS\\POS\\img\\카레라이스.png"));
                lstTable[i].listMenu.Add(new Menu("코카콜라", 1500, "음료수", "C:\\Users\\Jaws\\Desktop\\Develop\\C#\\POS\\POS\\img\\코카콜라.png"));
                lstTable[i].listMenu.Add(new Menu("펩시", 1000, "음료수", "C:\\Users\\Jaws\\Desktop\\Develop\\C#\\POS\\POS\\img\\펩시.png"));

            }

            history.Add(new History("김밥","김밥류",2000));
            history.Add(new History("참치김밥","김밥류",3000));
            history.Add(new History("돈까스김밥","김밥류",4000));
            history.Add(new History("라면","면류",3000));
            history.Add(new History("우동","면류",4000));
            history.Add(new History("잔치국수","면류",5000));
            history.Add(new History("비빔밥","식사류",5000));
            history.Add(new History("순두부찌개","식사류",6000));
            history.Add(new History("카레라이스","식사류",7000));
            history.Add(new History("코카콜라","음료수",1500));
            history.Add(new History("펩시","음료수",1000));

        }
        private void Order(object sender, EventHandler e, int tablenum)
        {
            string temp = string.Empty;
            foreach (Menu food in lstTable[tablenum].listMenu)
            {
                if (food.count > 0)
                {
                    temp += food.name + "X" + food.count.ToString() + "\n";
                }
            }
            switch (tablenum)
            {
                case 1: Table_1.Text = temp; break;
                case 2: Table_2.Text = temp; break;
                case 3: Table_3.Text = temp; break;
                case 4: Table_4.Text = temp; break;
                case 5: Table_5.Text = temp; break;
                case 6: Table_6.Text = temp; break;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Statistics stats = new Statistics();
            stats.Show();
        }
    }
}
