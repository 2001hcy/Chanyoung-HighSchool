﻿namespace POS.views
{
    partial class Statistics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Vol_KB = new System.Windows.Forms.Label();
            this.Vol_Noodle = new System.Windows.Forms.Label();
            this.Vol_Meal = new System.Windows.Forms.Label();
            this.Vol_Beverage = new System.Windows.Forms.Label();
            this.Sales_KB = new System.Windows.Forms.Label();
            this.Sales_Noodle = new System.Windows.Forms.Label();
            this.Sales_Meal = new System.Windows.Forms.Label();
            this.Sales_Beverage = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Label_Noodle = new System.Windows.Forms.Label();
            this.Label_BBB = new System.Windows.Forms.Label();
            this.Label_Udon = new System.Windows.Forms.Label();
            this.Label_Tofu = new System.Windows.Forms.Label();
            this.Label_Ramen = new System.Windows.Forms.Label();
            this.Label_Curry = new System.Windows.Forms.Label();
            this.Label_DKB = new System.Windows.Forms.Label();
            this.Label_Coke = new System.Windows.Forms.Label();
            this.Label_TKB = new System.Windows.Forms.Label();
            this.Label_Pepsi = new System.Windows.Forms.Label();
            this.Label_KB = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Label_Total = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("메이플스토리", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(255, 477);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "Total";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("메이플스토리", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(35, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 41);
            this.label2.TabIndex = 1;
            this.label2.Text = "김밥류";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(12, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 30);
            this.label3.TabIndex = 2;
            this.label3.Text = "판매량";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(12, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 30);
            this.label4.TabIndex = 3;
            this.label4.Text = "매출액";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(12, 230);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 30);
            this.label5.TabIndex = 6;
            this.label5.Text = "매출액";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(12, 191);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 30);
            this.label6.TabIndex = 5;
            this.label6.Text = "판매량";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("메이플스토리", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(35, 140);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 41);
            this.label7.TabIndex = 4;
            this.label7.Text = "면류";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(12, 361);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 30);
            this.label8.TabIndex = 9;
            this.label8.Text = "매출액";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(12, 322);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 30);
            this.label9.TabIndex = 8;
            this.label9.Text = "판매량";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("메이플스토리", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(35, 271);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(113, 41);
            this.label10.TabIndex = 7;
            this.label10.Text = "식사류";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.Location = new System.Drawing.Point(12, 493);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 30);
            this.label11.TabIndex = 12;
            this.label11.Text = "매출액";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.Location = new System.Drawing.Point(12, 454);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 30);
            this.label12.TabIndex = 11;
            this.label12.Text = "판매량";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("메이플스토리", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.Location = new System.Drawing.Point(35, 403);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(105, 41);
            this.label13.TabIndex = 10;
            this.label13.Text = "음료수";
            // 
            // Vol_KB
            // 
            this.Vol_KB.AutoSize = true;
            this.Vol_KB.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Vol_KB.Location = new System.Drawing.Point(103, 60);
            this.Vol_KB.Name = "Vol_KB";
            this.Vol_KB.Size = new System.Drawing.Size(62, 30);
            this.Vol_KB.TabIndex = 13;
            this.Vol_KB.Text = "0 개";
            // 
            // Vol_Noodle
            // 
            this.Vol_Noodle.AutoSize = true;
            this.Vol_Noodle.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Vol_Noodle.Location = new System.Drawing.Point(103, 191);
            this.Vol_Noodle.Name = "Vol_Noodle";
            this.Vol_Noodle.Size = new System.Drawing.Size(62, 30);
            this.Vol_Noodle.TabIndex = 14;
            this.Vol_Noodle.Text = "0 개";
            // 
            // Vol_Meal
            // 
            this.Vol_Meal.AutoSize = true;
            this.Vol_Meal.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Vol_Meal.Location = new System.Drawing.Point(103, 322);
            this.Vol_Meal.Name = "Vol_Meal";
            this.Vol_Meal.Size = new System.Drawing.Size(62, 30);
            this.Vol_Meal.TabIndex = 15;
            this.Vol_Meal.Text = "0 개";
            // 
            // Vol_Beverage
            // 
            this.Vol_Beverage.AutoSize = true;
            this.Vol_Beverage.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Vol_Beverage.Location = new System.Drawing.Point(103, 454);
            this.Vol_Beverage.Name = "Vol_Beverage";
            this.Vol_Beverage.Size = new System.Drawing.Size(62, 30);
            this.Vol_Beverage.TabIndex = 16;
            this.Vol_Beverage.Text = "0 개";
            // 
            // Sales_KB
            // 
            this.Sales_KB.AutoSize = true;
            this.Sales_KB.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Sales_KB.Location = new System.Drawing.Point(103, 99);
            this.Sales_KB.Name = "Sales_KB";
            this.Sales_KB.Size = new System.Drawing.Size(62, 30);
            this.Sales_KB.TabIndex = 17;
            this.Sales_KB.Text = "0 원";
            // 
            // Sales_Noodle
            // 
            this.Sales_Noodle.AutoSize = true;
            this.Sales_Noodle.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Sales_Noodle.Location = new System.Drawing.Point(103, 230);
            this.Sales_Noodle.Name = "Sales_Noodle";
            this.Sales_Noodle.Size = new System.Drawing.Size(62, 30);
            this.Sales_Noodle.TabIndex = 18;
            this.Sales_Noodle.Text = "0 원";
            // 
            // Sales_Meal
            // 
            this.Sales_Meal.AutoSize = true;
            this.Sales_Meal.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Sales_Meal.Location = new System.Drawing.Point(103, 361);
            this.Sales_Meal.Name = "Sales_Meal";
            this.Sales_Meal.Size = new System.Drawing.Size(62, 30);
            this.Sales_Meal.TabIndex = 19;
            this.Sales_Meal.Text = "0 원";
            // 
            // Sales_Beverage
            // 
            this.Sales_Beverage.AutoSize = true;
            this.Sales_Beverage.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Sales_Beverage.Location = new System.Drawing.Point(103, 493);
            this.Sales_Beverage.Name = "Sales_Beverage";
            this.Sales_Beverage.Size = new System.Drawing.Size(62, 30);
            this.Sales_Beverage.TabIndex = 20;
            this.Sales_Beverage.Text = "0 원";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label22.Location = new System.Drawing.Point(290, 20);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 30);
            this.label22.TabIndex = 21;
            this.label22.Text = "김밥";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label23.Location = new System.Drawing.Point(290, 60);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(108, 30);
            this.label23.TabIndex = 22;
            this.label23.Text = "참치김밥";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label24.Location = new System.Drawing.Point(290, 99);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(127, 30);
            this.label24.TabIndex = 23;
            this.label24.Text = "돈까스김밥";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label25.Location = new System.Drawing.Point(290, 140);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(61, 30);
            this.label25.TabIndex = 24;
            this.label25.Text = "라면";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label26.Location = new System.Drawing.Point(290, 179);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(56, 30);
            this.label26.TabIndex = 25;
            this.label26.Text = "우동";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label27.Location = new System.Drawing.Point(290, 220);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(104, 30);
            this.label27.TabIndex = 26;
            this.label27.Text = "잔치국수";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label28.Location = new System.Drawing.Point(290, 260);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(85, 30);
            this.label28.TabIndex = 27;
            this.label28.Text = "비빔밥";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label29.Location = new System.Drawing.Point(290, 299);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(125, 30);
            this.label29.TabIndex = 28;
            this.label29.Text = "순두부찌개";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label30.Location = new System.Drawing.Point(290, 338);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(129, 30);
            this.label30.TabIndex = 29;
            this.label30.Text = "카레라이스";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label31.Location = new System.Drawing.Point(290, 377);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(103, 30);
            this.label31.TabIndex = 30;
            this.label31.Text = "코카콜라";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label32.Location = new System.Drawing.Point(290, 411);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(61, 30);
            this.label32.TabIndex = 31;
            this.label32.Text = "펩시";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("굴림", 500F);
            this.textBox1.Location = new System.Drawing.Point(222, -11);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(10, 766);
            this.textBox1.TabIndex = 32;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("굴림", 6F);
            this.textBox2.Location = new System.Drawing.Point(222, 454);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(630, 10);
            this.textBox2.TabIndex = 33;
            // 
            // Label_Noodle
            // 
            this.Label_Noodle.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_Noodle.Location = new System.Drawing.Point(3, 208);
            this.Label_Noodle.Name = "Label_Noodle";
            this.Label_Noodle.Size = new System.Drawing.Size(166, 30);
            this.Label_Noodle.TabIndex = 39;
            this.Label_Noodle.Text = "0개, 0원 판매";
            this.Label_Noodle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_BBB
            // 
            this.Label_BBB.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_BBB.Location = new System.Drawing.Point(3, 248);
            this.Label_BBB.Name = "Label_BBB";
            this.Label_BBB.Size = new System.Drawing.Size(166, 30);
            this.Label_BBB.TabIndex = 40;
            this.Label_BBB.Text = "0개, 0원 판매";
            this.Label_BBB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_Udon
            // 
            this.Label_Udon.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_Udon.Location = new System.Drawing.Point(3, 167);
            this.Label_Udon.Name = "Label_Udon";
            this.Label_Udon.Size = new System.Drawing.Size(166, 30);
            this.Label_Udon.TabIndex = 38;
            this.Label_Udon.Text = "0개, 0원 판매";
            this.Label_Udon.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_Tofu
            // 
            this.Label_Tofu.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_Tofu.Location = new System.Drawing.Point(3, 287);
            this.Label_Tofu.Name = "Label_Tofu";
            this.Label_Tofu.Size = new System.Drawing.Size(166, 30);
            this.Label_Tofu.TabIndex = 41;
            this.Label_Tofu.Text = "0개, 0원 판매";
            this.Label_Tofu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_Ramen
            // 
            this.Label_Ramen.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_Ramen.Location = new System.Drawing.Point(3, 128);
            this.Label_Ramen.Name = "Label_Ramen";
            this.Label_Ramen.Size = new System.Drawing.Size(166, 30);
            this.Label_Ramen.TabIndex = 37;
            this.Label_Ramen.Text = "0개, 0원 판매";
            this.Label_Ramen.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_Curry
            // 
            this.Label_Curry.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_Curry.Location = new System.Drawing.Point(3, 326);
            this.Label_Curry.Name = "Label_Curry";
            this.Label_Curry.Size = new System.Drawing.Size(166, 30);
            this.Label_Curry.TabIndex = 42;
            this.Label_Curry.Text = "0개, 0원 판매";
            this.Label_Curry.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_DKB
            // 
            this.Label_DKB.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_DKB.Location = new System.Drawing.Point(3, 87);
            this.Label_DKB.Name = "Label_DKB";
            this.Label_DKB.Size = new System.Drawing.Size(166, 30);
            this.Label_DKB.TabIndex = 36;
            this.Label_DKB.Text = "0개, 0원 판매";
            this.Label_DKB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_Coke
            // 
            this.Label_Coke.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_Coke.Location = new System.Drawing.Point(3, 365);
            this.Label_Coke.Name = "Label_Coke";
            this.Label_Coke.Size = new System.Drawing.Size(166, 30);
            this.Label_Coke.TabIndex = 43;
            this.Label_Coke.Text = "0개, 0원 판매";
            this.Label_Coke.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_TKB
            // 
            this.Label_TKB.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_TKB.Location = new System.Drawing.Point(3, 48);
            this.Label_TKB.Name = "Label_TKB";
            this.Label_TKB.Size = new System.Drawing.Size(166, 30);
            this.Label_TKB.TabIndex = 35;
            this.Label_TKB.Text = "0개, 0원 판매";
            this.Label_TKB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_Pepsi
            // 
            this.Label_Pepsi.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_Pepsi.Location = new System.Drawing.Point(3, 402);
            this.Label_Pepsi.Name = "Label_Pepsi";
            this.Label_Pepsi.Size = new System.Drawing.Size(166, 30);
            this.Label_Pepsi.TabIndex = 44;
            this.Label_Pepsi.Text = "0개, 0원 판매";
            this.Label_Pepsi.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Label_Pepsi.Click += new System.EventHandler(this.Label_Pepsi_Click);
            // 
            // Label_KB
            // 
            this.Label_KB.Font = new System.Drawing.Font("메이플스토리", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_KB.Location = new System.Drawing.Point(3, 8);
            this.Label_KB.Name = "Label_KB";
            this.Label_KB.Size = new System.Drawing.Size(166, 30);
            this.Label_KB.TabIndex = 34;
            this.Label_KB.Text = "0개, 0원 판매";
            this.Label_KB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Label_KB);
            this.panel1.Controls.Add(this.Label_Pepsi);
            this.panel1.Controls.Add(this.Label_TKB);
            this.panel1.Controls.Add(this.Label_Coke);
            this.panel1.Controls.Add(this.Label_DKB);
            this.panel1.Controls.Add(this.Label_Curry);
            this.panel1.Controls.Add(this.Label_Ramen);
            this.panel1.Controls.Add(this.Label_Tofu);
            this.panel1.Controls.Add(this.Label_Udon);
            this.panel1.Controls.Add(this.Label_BBB);
            this.panel1.Controls.Add(this.Label_Noodle);
            this.panel1.Location = new System.Drawing.Point(642, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(171, 436);
            this.panel1.TabIndex = 45;
            // 
            // Label_Total
            // 
            this.Label_Total.Font = new System.Drawing.Font("메이플스토리", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_Total.Location = new System.Drawing.Point(514, 469);
            this.Label_Total.Name = "Label_Total";
            this.Label_Total.Size = new System.Drawing.Size(297, 57);
            this.Label_Total.TabIndex = 45;
            this.Label_Total.Text = "총 0개, 0원 판매";
            this.Label_Total.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Statistics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 527);
            this.Controls.Add(this.Label_Total);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.Sales_Beverage);
            this.Controls.Add(this.Sales_Meal);
            this.Controls.Add(this.Sales_Noodle);
            this.Controls.Add(this.Sales_KB);
            this.Controls.Add(this.Vol_Beverage);
            this.Controls.Add(this.Vol_Meal);
            this.Controls.Add(this.Vol_Noodle);
            this.Controls.Add(this.Vol_KB);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Statistics";
            this.Text = "Statistics";
            this.Load += new System.EventHandler(this.Statistics_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label Vol_KB;
        private System.Windows.Forms.Label Vol_Noodle;
        private System.Windows.Forms.Label Vol_Meal;
        private System.Windows.Forms.Label Vol_Beverage;
        private System.Windows.Forms.Label Sales_KB;
        private System.Windows.Forms.Label Sales_Noodle;
        private System.Windows.Forms.Label Sales_Meal;
        private System.Windows.Forms.Label Sales_Beverage;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label Label_Noodle;
        private System.Windows.Forms.Label Label_BBB;
        private System.Windows.Forms.Label Label_Udon;
        private System.Windows.Forms.Label Label_Tofu;
        private System.Windows.Forms.Label Label_Ramen;
        private System.Windows.Forms.Label Label_Curry;
        private System.Windows.Forms.Label Label_DKB;
        private System.Windows.Forms.Label Label_Coke;
        private System.Windows.Forms.Label Label_TKB;
        private System.Windows.Forms.Label Label_Pepsi;
        private System.Windows.Forms.Label Label_KB;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Label_Total;
    }
}