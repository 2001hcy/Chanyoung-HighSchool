﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS.views
{
    public partial class Loading : Form
    {
        public Loading()
        {
            InitializeComponent();
            timer = new System.Windows.Forms.Timer();
            timer.Interval = 30;
            timer.Tick += new EventHandler(Timer_Tick);
            timer.Start();
            pbLoading.Step = 1;
            pbLoading.Maximum = 100;
            
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (pbLoading.Value == pbLoading.Maximum)
            {
                timer.Stop();
                Thread thread = new Thread(() =>
                {
                    Thread.Sleep(500);
                    BeginInvoke((Action)(() =>
                    {
                        Close();
                    }));
                });
                thread.Start();
            }
            pbLoading.PerformStep();
        }
    }
}
