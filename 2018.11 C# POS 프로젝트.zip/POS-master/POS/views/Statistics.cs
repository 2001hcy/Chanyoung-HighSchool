﻿using POS.classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static POS.Main;

namespace POS.views
{
    partial class Statistics : Form
    {
        
        int KB_Volume = 0, KB_Sales = 0;
        int Noodle_Volume = 0, Noodle_Sales = 0;
        int Meal_Volume = 0, Meal_Sales = 0;
        int Beverage_Volume = 0, Beverage_Sales = 0;

        private void Label_Pepsi_Click(object sender, EventArgs e)
        {

        }

        public Statistics()
        {
            
            InitializeComponent();
        }


        private void Statistics_Load(object sender, EventArgs e)
        {
            string str = string.Empty;
            foreach (History history in history)
            {
                switch (history.name)
                {
                    case "김밥": Label_KB.Text = history.count + "개," + history.count * history.price + "원 판매"; break;
                    case "참치김밥": Label_TKB.Text = history.count + "개," + history.count * history.price + "원 판매"; break;
                    case "돈까스김밥": Label_DKB.Text = history.count + "개," + history.count * history.price + "원 판매"; break;
                    case "라면": Label_Ramen.Text = history.count + "개," + history.count * history.price + "원 판매"; break;
                    case "우동": Label_Udon.Text = history.count + "개," + history.count * history.price + "원 판매"; break;
                    case "잔치국수": Label_Noodle.Text = history.count + "개," + history.count * history.price + "원 판매"; break;
                    case "비빔밥": Label_BBB.Text = history.count + "개," + history.count * history.price + "원 판매"; break;
                    case "순두부끼재": Label_Tofu.Text = history.count + "개," + history.count * history.price + "원 판매"; break;
                    case "카레라이스": Label_Curry.Text = history.count + "개," + history.count * history.price + "원 판매"; break;
                    case "코카콜라": Label_Coke.Text = history.count + "개," + history.count * history.price + "원 판매"; break;
                    case "펩시": Label_Pepsi.Text = history.count + "개," + history.count * history.price + "원 판매"; break;
                }
                switch (history.category)
                {
                    case "김밥류":KB_Volume += history.count; KB_Sales += history.price * history.count; break;
                    case "면류":Noodle_Volume += history.count; Noodle_Sales += history.price * history.count; break;
                    case "식사류":Meal_Volume += history.count; Meal_Sales += history.price * history.count; break;
                    case "음료수":Beverage_Volume += history.count; Beverage_Sales += history.price * history.count; break;
                }
                LoadScreen();
            }
        }

        private void LoadScreen()
        {
            Vol_KB.Text = KB_Volume.ToString() + " 개";
            Sales_KB.Text = KB_Sales.ToString() + " 원";
            Vol_Noodle.Text = Noodle_Volume.ToString() + " 개";
            Sales_Noodle.Text = Noodle_Sales.ToString() + " 원";
            Vol_Meal.Text = Meal_Volume.ToString() + " 개";
            Sales_Meal.Text = Meal_Sales.ToString() + " 원";
            Vol_Beverage.Text = Beverage_Volume.ToString() + " 개";
            Sales_Beverage.Text = Beverage_Sales.ToString() + " 원";
            Label_Total.Text = "총 " + (KB_Volume + Noodle_Volume + Meal_Volume + Beverage_Volume) +
                               "개, " + (KB_Sales + Noodle_Sales + Meal_Sales + Beverage_Sales) +"원 판매";
        }
    }
}
