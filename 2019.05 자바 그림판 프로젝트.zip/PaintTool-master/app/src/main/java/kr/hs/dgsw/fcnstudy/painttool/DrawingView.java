package kr.hs.dgsw.fcnstudy.painttool;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

public class DrawingView extends AppCompatImageView implements View.OnTouchListener {

    private Paint paint;
    private float x = -1, y = -1;
    private Path path;
    private ArrayList<Path> paths;
    private int color;
    private ArrayList<Integer> colors;

    private void init() {
        paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(15);
        paint.setAntiAlias(true);

        path = new Path();
        paths = new ArrayList<>();
        color = Color.BLACK;
        colors = new ArrayList<>();

        setOnTouchListener(this);
    }

    public DrawingView(Context context) {
        super(context);
        init();
    }
    public DrawingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }
    public DrawingView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (int i = 0;i<paths.size();i++){
            Log.d("DV","Stored Path " + i);
            paint.setColor(colors.get(i));
            canvas.drawPath(paths.get(i),paint);
        }
        paint.setColor(color);
        canvas.drawPath(path,paint);
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                path.moveTo(motionEvent.getX(),motionEvent.getY());
                break;
            case MotionEvent.ACTION_MOVE:
                x = motionEvent.getX();
                y = motionEvent.getY();
                path.lineTo(motionEvent.getX(),motionEvent.getY());
                break;
            case MotionEvent.ACTION_UP:
                paths.add(path);
                colors.add(color);
                break;
        }
        invalidate();
        return false;
    }

    public void setColor(int color){
        path = new Path();
        this.color = color;
    }
}
