package kr.hs.dgsw.fcnstudy.painttool;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    private DrawingView drawingView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        drawingView = findViewById(R.id.drawingView);
    }

    protected void onColorClick(View view){
        int color = 0;
        if (view.getId() == R.id.radioButtonBlack) {
            color = Color.BLACK;
        } else if (view.getId() == R.id.radioButtonRed) {
            color = Color.RED;
        } else if (view.getId() == R.id.radioButtonBlue){
            color = Color.BLUE;
        }
        drawingView.setColor(color);
    }
}
