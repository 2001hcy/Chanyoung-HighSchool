﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ToDo
{
    class HashConvert
    {
        public string ConvertSha256(string pwd)
        {
            var Sha256 = new SHA256CryptoServiceProvider();
            byte[] ResultHash = Sha256.ComputeHash(Encoding.Default.GetBytes(pwd));
            StringBuilder TransPwd = new StringBuilder();
            foreach(var hash in ResultHash)
            {
                TransPwd.AppendFormat("{0:x2}", hash);
            }
            return TransPwd.ToString();
        }
    }
}
