﻿namespace ToDo.View
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addButton = new MaterialSkin.Controls.MaterialRaisedButton();
            this.IDBox = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.PWBox = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.Registerbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // addButton
            // 
            this.addButton.Depth = 0;
            this.addButton.Location = new System.Drawing.Point(282, 69);
            this.addButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.addButton.Name = "addButton";
            this.addButton.Primary = true;
            this.addButton.Size = new System.Drawing.Size(57, 66);
            this.addButton.TabIndex = 5;
            this.addButton.Text = "Login";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.Login_Click);
            // 
            // IDBox
            // 
            this.IDBox.Depth = 0;
            this.IDBox.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.IDBox.Hint = "";
            this.IDBox.Location = new System.Drawing.Point(12, 74);
            this.IDBox.MouseState = MaterialSkin.MouseState.HOVER;
            this.IDBox.Name = "IDBox";
            this.IDBox.PasswordChar = '\0';
            this.IDBox.SelectedText = "";
            this.IDBox.SelectionLength = 0;
            this.IDBox.SelectionStart = 0;
            this.IDBox.Size = new System.Drawing.Size(263, 23);
            this.IDBox.TabIndex = 4;
            this.IDBox.UseSystemPasswordChar = false;
            // 
            // PWBox
            // 
            this.PWBox.Depth = 0;
            this.PWBox.Font = new System.Drawing.Font("메이플스토리", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.PWBox.Hint = "";
            this.PWBox.Location = new System.Drawing.Point(12, 112);
            this.PWBox.MouseState = MaterialSkin.MouseState.HOVER;
            this.PWBox.Name = "PWBox";
            this.PWBox.PasswordChar = '\0';
            this.PWBox.SelectedText = "";
            this.PWBox.SelectionLength = 0;
            this.PWBox.SelectionStart = 0;
            this.PWBox.Size = new System.Drawing.Size(263, 23);
            this.PWBox.TabIndex = 6;
            this.PWBox.UseSystemPasswordChar = false;
            // 
            // Registerbtn
            // 
            this.Registerbtn.Font = new System.Drawing.Font("궁서", 20F);
            this.Registerbtn.Location = new System.Drawing.Point(13, 142);
            this.Registerbtn.Name = "Registerbtn";
            this.Registerbtn.Size = new System.Drawing.Size(325, 46);
            this.Registerbtn.TabIndex = 7;
            this.Registerbtn.Text = "회원가입";
            this.Registerbtn.UseVisualStyleBackColor = true;
            this.Registerbtn.Click += new System.EventHandler(this.Registerbtn_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 200);
            this.Controls.Add(this.Registerbtn);
            this.Controls.Add(this.PWBox);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.IDBox);
            this.Name = "Login";
            this.Text = "Login";
            this.ResumeLayout(false);

        }

        #endregion

        private MaterialSkin.Controls.MaterialRaisedButton addButton;
        private MaterialSkin.Controls.MaterialSingleLineTextField IDBox;
        private MaterialSkin.Controls.MaterialSingleLineTextField PWBox;
        private System.Windows.Forms.Button Registerbtn;
    }
}