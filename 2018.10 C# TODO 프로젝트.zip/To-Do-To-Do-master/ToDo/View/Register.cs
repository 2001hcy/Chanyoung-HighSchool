﻿using MaterialSkin;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToDo.View
{
    public partial class Register : MaterialSkin.Controls.MaterialForm
    {
        public Register()
        {
            InitializeComponent();
            var skinManager = MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            skinManager.ColorScheme = new ColorScheme(Primary.Red200, Primary.Red300, Primary.Red300, Accent.Red100, TextShade.WHITE);  //skinManager 색상들 설정.
            PWBox.PasswordChar = '凸';
        }
        private string strSQL = ConfigurationManager.AppSettings["DBconn"];
        HashConvert convert = new HashConvert();

        private void addButton_Click(object sender, EventArgs e)
        {
            Check();
            JOIN();
        }

        void Check()
        {
            string str = "";
            if (IDBox.Text == "") str = "아이디";
            else if (PWBox.Text == "") str = "비밀번호";
            else if (NameBox.Text == "") str = "이름";
            if (str == "") return;
            else
            {
                MessageBox.Show(str + "를 입력하지 않았습니다.","알림",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
        }
        bool IDCHECK()
        {
            var Conn = new MySqlConnection(strSQL);
            Conn.Open();
            var comm = new MySqlCommand("select * from User where id='"+IDBox.Text+"'",Conn);
            var MyRead = comm.ExecuteReader();
            while (MyRead.Read())
            {
                MessageBox.Show("이미 존재하는 ID 입니다", "알림",MessageBoxButtons.OK,MessageBoxIcon.Error);
                IDBox.Text = "";
                IDBox.Focus();
                MyRead.Close();
                Conn.Close();
                return false;
            }
            MyRead.Close();
            Conn.Close();
            return true;
        }

        void JOIN()
        {
            if(IDCHECK() == true)
            {
                var Conn = new MySqlConnection(strSQL);
                Conn.Open();
                string sql = "insert into User (ID, PW, Name) values ('"+IDBox.Text+"','"+convert.ConvertSha256(PWBox.Text)+ "','"+NameBox.Text+"')";
                var comm = new MySqlCommand(sql, Conn);
                int i = comm.ExecuteNonQuery();
                if(i == 1)
                {
                    MessageBox.Show("회원가입 성공!","성공ㅇ고공고곡ㅋ고코코볼",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("회원가입 실패!","실패ㅅㅣㅍ래패패ㅐ팹펩시",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
                Conn.Close();
            }
        }
    }
}
