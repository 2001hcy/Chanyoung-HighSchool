﻿using System;
using System.Configuration;
using System.Data;
using System.Windows.Forms;
using MaterialSkin;
using MySql.Data.MySqlClient;

namespace ToDo.View
{
    public partial class Main : MaterialSkin.Controls.MaterialForm
    {
        private string strSQL = ConfigurationManager.AppSettings["DBconn"];
        string ID = "";
        public Main(string id)
        {
            InitializeComponent();
            var skinManager = MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            skinManager.ColorScheme = new ColorScheme(Primary.Red200, Primary.Red300, Primary.Red300, Accent.Red100, TextShade.WHITE);  //skinManager 색상들 설정.
            ID = id;
            Reload();
        }
        private void Todo_Add(object sender, EventArgs e)
        {
            string data = textBox.Text;
            if (data == "") return;
            var Conn = new MySqlConnection(strSQL);
            Conn.Open();
            string sql = "insert into List (ID,todo) values ('" + ID + "','" + data + "')";
            var command = new MySqlCommand(sql, Conn);
            int i = command.ExecuteNonQuery();
            sql = "insert into detail (ID,todo,date,memo) values ('" + ID + "','" + data + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "','상세 정보를 입력하세요')";
            command = new MySqlCommand(sql, Conn);
            i = command.ExecuteNonQuery();
            Conn.Close();
            textBox.Text = string.Empty; data = string.Empty;
            Reload();
            
        }
        void Reload()
        {
            var Conn = new MySqlConnection(strSQL);
            MySqlCommand command = new MySqlCommand() { Connection = Conn };
            DataSet dataSet = new DataSet();
            MySqlDataAdapter dataAdapter = new MySqlDataAdapter("SELECT * FROM List where id='" + ID + "'", Conn);
            dataAdapter.Fill(dataSet);
            TodoList.Items.Clear();
            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                TodoList.Items.Add(row["todo"]);
            }
            textBox.Focus();
        }

        private void DeleteButton_Clicked(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            if (button.Text.Contains("All"))    //전체삭제
            {
                Delete_ALL();
            }
            else
            {
                Delete_Selected();
            }
        }

        void Delete_ALL()
        {
            var Conn = new MySqlConnection(strSQL);
            Conn.Open();
            string sql = "delete from List where ID='" + ID + "'";
            var command = new MySqlCommand(sql, Conn);
            int i = command.ExecuteNonQuery();
            Conn.Close();
            Reload();
        }
        void Delete_Selected()
        {
            string sql = "";
            var Conn = new MySqlConnection(strSQL);
            var command = new MySqlCommand();
            Conn.Open();
            for (int i = TodoList.CheckedItems.Count; i > 0; i--)
            {
                sql = "delete from List where ID='" + ID + "' and todo='" + TodoList.CheckedItems[i-1].ToString() + "'";
                command = new MySqlCommand(sql, Conn);
                command.ExecuteNonQuery();
            }
            Conn.Close();
            Reload();
        }

        private void DetailView(object sender, EventArgs e)
        {
            string todo = TodoList.SelectedItems[0].ToString();
            Detail detail = new Detail(ID,todo);
            detail.ShowDialog();
        }
    }
}
