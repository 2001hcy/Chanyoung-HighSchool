﻿using MaterialSkin;
using System;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace ToDo.View
{
    public partial class Login : MaterialSkin.Controls.MaterialForm
    {
        private string strSQL = ConfigurationManager.AppSettings["DBconn"];
        HashConvert convert = new HashConvert();
        public Login()
        {
            InitializeComponent();
            var skinManager = MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            skinManager.ColorScheme = new ColorScheme(Primary.Red200, Primary.Red300, Primary.Red300, Accent.Red100, TextShade.WHITE);  //skinManager 색상들 설정.
            PWBox.PasswordChar = '凸';
        }
        private void Login_Click(object sender, EventArgs e)
        {   
            string data = IDBox.Text;
            if (data == "")
            {
                MessageBox.Show("아이디를 입력하세요", "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (PWBox.Text == "")
            {
                MessageBox.Show("비밀번호를 입력하세요", "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                sqlLogin();
                return;
            }
        }

        private void Registerbtn_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            register.ShowDialog();
        }

        void sqlLogin()
        {
            var Conn = new MySqlConnection(strSQL);
            Conn.Open();
            var comm = new MySqlCommand("select id,pw from User where id='" + IDBox.Text + "'", Conn);
            var MyRead = comm.ExecuteReader();
            while (MyRead.Read())
            {
                string pw = MyRead[1].ToString();
                Console.WriteLine(convert.ConvertSha256(PWBox.Text));
                if(convert.ConvertSha256(PWBox.Text) == pw)
                {
                    MessageBox.Show("로그인에 성공했습니다", "성고고고오고오고오고고", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Main main = new Main(IDBox.Text);
                    main.Show();
                    main.FormClosed += Main_FormClosed;
                    MyRead.Close();
                    Conn.Close();
                    Visible = false;
                    return;
                }
            }
            MessageBox.Show("아이디/비밀번호가 맞지 않습니다아아앙ㅇㄱ악", "실패패패래패패래패패", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            Close();
        }
    }
}
