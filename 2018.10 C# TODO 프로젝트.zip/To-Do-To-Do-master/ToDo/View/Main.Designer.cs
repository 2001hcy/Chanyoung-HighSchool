﻿namespace ToDo.View
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.addButton = new MaterialSkin.Controls.MaterialRaisedButton();
            this.TodoList = new System.Windows.Forms.CheckedListBox();
            this.clearCheckedButton = new MaterialSkin.Controls.MaterialRaisedButton();
            this.clearAllButton = new MaterialSkin.Controls.MaterialRaisedButton();
            this.SuspendLayout();
            // 
            // textBox
            // 
            this.textBox.Depth = 0;
            this.textBox.Font = new System.Drawing.Font("메이플스토리", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox.Hint = "";
            this.textBox.Location = new System.Drawing.Point(10, 75);
            this.textBox.MouseState = MaterialSkin.MouseState.HOVER;
            this.textBox.Name = "textBox";
            this.textBox.PasswordChar = '\0';
            this.textBox.SelectedText = "";
            this.textBox.SelectionLength = 0;
            this.textBox.SelectionStart = 0;
            this.textBox.Size = new System.Drawing.Size(263, 23);
            this.textBox.TabIndex = 2;
            this.textBox.UseSystemPasswordChar = false;
            // 
            // addButton
            // 
            this.addButton.Depth = 0;
            this.addButton.Location = new System.Drawing.Point(280, 70);
            this.addButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.addButton.Name = "addButton";
            this.addButton.Primary = true;
            this.addButton.Size = new System.Drawing.Size(57, 27);
            this.addButton.TabIndex = 3;
            this.addButton.Text = "+";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.Todo_Add);
            // 
            // TodoList
            // 
            this.TodoList.FormattingEnabled = true;
            this.TodoList.Location = new System.Drawing.Point(10, 103);
            this.TodoList.Margin = new System.Windows.Forms.Padding(2);
            this.TodoList.Name = "TodoList";
            this.TodoList.Size = new System.Drawing.Size(327, 228);
            this.TodoList.TabIndex = 5;
            this.TodoList.DoubleClick += new System.EventHandler(this.DetailView);
            // 
            // clearCheckedButton
            // 
            this.clearCheckedButton.Depth = 0;
            this.clearCheckedButton.Font = new System.Drawing.Font("메이플스토리", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.clearCheckedButton.Location = new System.Drawing.Point(10, 360);
            this.clearCheckedButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.clearCheckedButton.Name = "clearCheckedButton";
            this.clearCheckedButton.Primary = true;
            this.clearCheckedButton.Size = new System.Drawing.Size(160, 30);
            this.clearCheckedButton.TabIndex = 8;
            this.clearCheckedButton.Text = "Delete Selected";
            this.clearCheckedButton.UseVisualStyleBackColor = true;
            this.clearCheckedButton.MouseCaptureChanged += new System.EventHandler(this.DeleteButton_Clicked);
            // 
            // clearAllButton
            // 
            this.clearAllButton.Depth = 0;
            this.clearAllButton.Location = new System.Drawing.Point(177, 360);
            this.clearAllButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.clearAllButton.Name = "clearAllButton";
            this.clearAllButton.Primary = true;
            this.clearAllButton.Size = new System.Drawing.Size(160, 30);
            this.clearAllButton.TabIndex = 7;
            this.clearAllButton.Text = "Delete All";
            this.clearAllButton.UseVisualStyleBackColor = true;
            this.clearAllButton.Click += new System.EventHandler(this.DeleteButton_Clicked);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 400);
            this.Controls.Add(this.clearCheckedButton);
            this.Controls.Add(this.clearAllButton);
            this.Controls.Add(this.TodoList);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.textBox);
            this.MaximumSize = new System.Drawing.Size(350, 400);
            this.MinimumSize = new System.Drawing.Size(350, 400);
            this.Name = "Main";
            this.Text = "Todo";
            this.ResumeLayout(false);

        }

        #endregion

        private MaterialSkin.Controls.MaterialSingleLineTextField textBox;
        private MaterialSkin.Controls.MaterialRaisedButton addButton;
        private System.Windows.Forms.CheckedListBox TodoList;
        private MaterialSkin.Controls.MaterialRaisedButton clearCheckedButton;
        private MaterialSkin.Controls.MaterialRaisedButton clearAllButton;
    }
}