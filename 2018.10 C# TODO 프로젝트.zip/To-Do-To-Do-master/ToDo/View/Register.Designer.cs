﻿namespace ToDo.View
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PWBox = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.addButton = new MaterialSkin.Controls.MaterialRaisedButton();
            this.IDBox = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.NameBox = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.SuspendLayout();
            // 
            // PWBox
            // 
            this.PWBox.Depth = 0;
            this.PWBox.Font = new System.Drawing.Font("메이플스토리", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.PWBox.Hint = "";
            this.PWBox.Location = new System.Drawing.Point(84, 114);
            this.PWBox.MouseState = MaterialSkin.MouseState.HOVER;
            this.PWBox.Name = "PWBox";
            this.PWBox.PasswordChar = '\0';
            this.PWBox.SelectedText = "";
            this.PWBox.SelectionLength = 0;
            this.PWBox.SelectionStart = 0;
            this.PWBox.Size = new System.Drawing.Size(263, 23);
            this.PWBox.TabIndex = 9;
            this.PWBox.UseSystemPasswordChar = false;
            // 
            // addButton
            // 
            this.addButton.Depth = 0;
            this.addButton.Location = new System.Drawing.Point(353, 71);
            this.addButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.addButton.Name = "addButton";
            this.addButton.Primary = true;
            this.addButton.Size = new System.Drawing.Size(57, 109);
            this.addButton.TabIndex = 8;
            this.addButton.Text = "참여";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // IDBox
            // 
            this.IDBox.Depth = 0;
            this.IDBox.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.IDBox.Hint = "";
            this.IDBox.Location = new System.Drawing.Point(84, 71);
            this.IDBox.MouseState = MaterialSkin.MouseState.HOVER;
            this.IDBox.Name = "IDBox";
            this.IDBox.PasswordChar = '\0';
            this.IDBox.SelectedText = "";
            this.IDBox.SelectionLength = 0;
            this.IDBox.SelectionStart = 0;
            this.IDBox.Size = new System.Drawing.Size(263, 23);
            this.IDBox.TabIndex = 7;
            this.IDBox.UseSystemPasswordChar = false;
            // 
            // NameBox
            // 
            this.NameBox.Depth = 0;
            this.NameBox.Font = new System.Drawing.Font("메이플스토리", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.NameBox.Hint = "";
            this.NameBox.Location = new System.Drawing.Point(84, 157);
            this.NameBox.MouseState = MaterialSkin.MouseState.HOVER;
            this.NameBox.Name = "NameBox";
            this.NameBox.PasswordChar = '\0';
            this.NameBox.SelectedText = "";
            this.NameBox.SelectionLength = 0;
            this.NameBox.SelectionStart = 0;
            this.NameBox.Size = new System.Drawing.Size(263, 23);
            this.NameBox.TabIndex = 10;
            this.NameBox.UseSystemPasswordChar = false;
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(13, 71);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(42, 19);
            this.materialLabel1.TabIndex = 11;
            this.materialLabel1.Text = "아이디";
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(13, 118);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(53, 19);
            this.materialLabel2.TabIndex = 12;
            this.materialLabel2.Text = "비밀번호";
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel3.Location = new System.Drawing.Point(13, 157);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(31, 19);
            this.materialLabel3.TabIndex = 13;
            this.materialLabel3.Text = "이름";
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 191);
            this.Controls.Add(this.materialLabel3);
            this.Controls.Add(this.materialLabel2);
            this.Controls.Add(this.materialLabel1);
            this.Controls.Add(this.NameBox);
            this.Controls.Add(this.PWBox);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.IDBox);
            this.Name = "Register";
            this.Text = "Register";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialSingleLineTextField PWBox;
        private MaterialSkin.Controls.MaterialRaisedButton addButton;
        private MaterialSkin.Controls.MaterialSingleLineTextField IDBox;
        private MaterialSkin.Controls.MaterialSingleLineTextField NameBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
    }
}