﻿using MaterialSkin;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToDo.View
{
    public partial class Detail : MaterialSkin.Controls.MaterialForm
    {
        string ID = ""; string TODO = "";
        private string strSQL = ConfigurationManager.AppSettings["DBconn"];
        public Detail(string id, string todo)
        {
            InitializeComponent();
            var skinManager = MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            skinManager.ColorScheme = new ColorScheme(Primary.Red200, Primary.Red300, Primary.Red300, Accent.Red100, TextShade.WHITE);  //skinManager 색상들 설정.
            NameLabel.Text = todo;
            ID = id;    TODO = todo;
        }

        private void Detail_Load(object sender, EventArgs e)
        {
            var Conn = new MySqlConnection(strSQL);
            Conn.Open();
            string sql = "select memo,date from detail where ID='"+ID+"' and todo='"+TODO+"'";
            Console.WriteLine(sql);
            var comm = new MySqlCommand(sql, Conn);
            var MyRead = comm.ExecuteReader();
            while (MyRead.Read())
            {
                memobox.Text = MyRead[0].ToString();
                DateLabel.Text = MyRead[1].ToString().Substring(0, MyRead[1].ToString().IndexOf("오전"));
            }
            Conn.Close();
        }

        private void ApplyButton_Click(object sender, EventArgs e)
        {
            var Conn = new MySqlConnection(strSQL);
            Conn.Open();
            string sql = "update detail set memo='"+memobox.Text+"' where ID='"+ID+"' and todo='"+TODO+"'";
            var command = new MySqlCommand(sql, Conn);
            int i = command.ExecuteNonQuery();
            Conn.Close();
            Close();
        }
    }
}
