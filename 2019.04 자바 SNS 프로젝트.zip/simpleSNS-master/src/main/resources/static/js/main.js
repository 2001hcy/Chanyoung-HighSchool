let loginflag = 0;
function openLoginDialog() {
    $("#login_container").css('display','flex').show();
}
function closeLoginDialog() {
    $("#login_container").hide();
}
function openRegisterDialog() {
    $("#register_container").css('display','flex').show();
}
function closeRegisterDialog() {
    $("#register_container").hide();
}
function openWriteDialog() {
    $("#write_container").css('display','flex').show();
}
function closeWriteDialog() {
    $("#write_container").hide();
}

function openUpdateDialog() {
    $("#update_container").css('display','flex').show();
}
function closeUpdateDialog() {
    $("#update_container").hide();
}