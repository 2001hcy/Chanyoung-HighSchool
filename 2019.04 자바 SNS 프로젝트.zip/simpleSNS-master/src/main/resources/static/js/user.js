async function login() {
    try {
        let userinfo = {
            id: $('#login_inputID').val(),
            password: $('#login_inputPW').val()
        };
        let response = await $.ajax({
            type: "POST",
            url: "/user/login/1",
            contentType: "application/json",
            data: JSON.stringify(userinfo)
        });
        if (response !== "") {
            loginflag = 1;
            alert("로그인 성공");
            login_success(response);
        } else {
            alert("아이디 또는 비밀번호가 틀렸습니다");
        }
    } catch (err) {
    }
}

async function register() {
    if (checkIfInputsEmpty()) return false;
    try {
        let id = $('#register_inputID');
        let password = $('#register_inputPW');
        let username = $('#register_inputName');
        let email = $('#register_inputEmail');

        let userinfo = {
            id: id.val(),
            password: password.val(),
            username: username.val(),
            email: email.val(),
            profileImagePath: "images\\default\\default.jpg",
            profileImageName: "default.jpg",
        };
        let response = await $.ajax({
            type: "POST",
            url: "/user/add",
            contentType: "application/json",
            data: JSON.stringify(userinfo)
        });
        if (response !== "") {
            alert("회원가입 성공");
            id.val("");
            password.val("");
            username.val("");
            email.val("");
            closeRegisterDialog();
        } else {
            alert("이미 존재하는 아이디 입니다.");
        }
    } catch (err) {
    }
}


function checkIfInputsEmpty() {
    let id = $('#register_inputID').val();
    let pw = $('#register_inputPW').val();
    let email = $('#register_inputEmail').val();
    let name = $('#register_inputName').val();
    if (id === "" || pw === "" || email === "" || name === "") {
        alert("모든 칸을 채워주세요");
        return true;
    } else {
        return false;
    }
}

function login_success(response) {
    $("#aside_default").hide();
    $("#login_container").hide();
    $("#aside_logined").css('display', '').show();
    $("#aside_ProfileImage").attr("src", response.profileImagePath);
    $("#aside_FieldID").html(response.id + "님");
    $("#aside_FieldEmail").html(response.email);
    let time = new Date(response.joined);
    let date = `가입일시:${time.getFullYear()}년 ${time.getMonth()}월 ${ time.getDate()}일 \n ${time.getHours()}시 ${time.getMinutes()}분 ${time.getSeconds()}초`;
    $("#aside_FieldJoined").html(date);
}


