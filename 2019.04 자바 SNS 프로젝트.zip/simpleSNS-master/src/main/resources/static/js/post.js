async function getAllPosts() {
    try {
        let response = await $.get('/post/list');
        $('#posts_list').html("");
        for (let i = 0; i < response.length; i++) {
            let post = response[i];
            $('#posts_list').prepend(`
                    <div class="posts" id="post_${post.postIndex}" >
                        <img id="postImage_${post.postIndex}" style="width: 250px;margin-left: -2%;height:250px " src="${post.attachedPath}">
                        <hr>
                        <div id="postTitle_${post.postIndex}" style="font-size: 20pt">${post.title}</div>
                        <div id="postComment_${post.postIndex}" style="margin: 0 0 10px 10px">${post.comment}</div>
                        <div style="position:absolute; bottom:0">
                            <button onclick="updatePostButtonClicked(${post.postIndex})" class="postButtons" style="margin:0 7px 10px -15px;">수정</button>
                            <button onclick="closeUpdateDialog()" class="postButtons">삭제</button>
                        </div>
                    </div>
                `);
            if (post.attachedPath === null || post.attachedPath === "") {
                $(`#postImage_${post.postIndex}`).attr("src", "/images/default/noimage.jpg");
            }
        }
    } catch (err) {
        alert("?");
    }
}

async function writePostButtonClicked() {
    if (checkIfLogined()) {
        return 0;
    } else {
        openWriteDialog();
    }
}

async function updatePostButtonClicked(postIndex) {
    if (checkIfLogined()) {
        return 0;
    } else {
        let title = $(`#postTitle_${postIndex}`).html();
        let comment = $(`#postComment_${postIndex}`).html();
        $(`#update_preview`).attr("src", "/images/default/uploadpreview.jpg");
        $('#update_inputTitle').val(title);
        $('#update_inputContent').val(comment);
        $('#update_buttonSubmit').attr("onclick", `updatePost(${postIndex})`);
        openUpdateDialog();
    }
}

$(function () {
    $("#write_attach").on('change', function () {
        readURL(this);
    });
    $("#update_attach").on('change', function () {
        readURL(this);
    });
});

function readURL(input) {
    if (input.files && input.files[0]) {
        let reader = new FileReader();
        reader.onload = function (e) {
            $('.write_imagePreview').attr('src', e.target.result);
        };
        reader.readAsDataURL(input.files[0]);
    }
}

async function updatePost(postIndex) {
    try {
        let file = $('#update_attach')[0].files[0];
        let response;
        if (file === undefined) {
            response = {
                profileImagePath: "",
                profileImageName: ""
            }
        } else {
            let srcFile = new FormData();
            srcFile.append('srcFile', file);
            response = await $.ajax({
                type: 'POST',
                url: `/post/attachment`,
                data: srcFile,
                processData: false,
                contentType: false
            });
        }
        let newPost = {
            title: $('#update_inputTitle').val(),
            comment: $('#update_inputContent').val(),
            attachedName: response.profileImageName,
            attachedPath: response.profileImagePath
        };
        response = await $.ajax({
            type: "POST",
            url: `/post/update/${postIndex}`,
            contentType: "application/json",
            data: JSON.stringify(newPost)
        });
        $('#update_inputContent').val("");
        $('#update_inputTitle').val("");
        $('#update_attach').val("");
        getAllPosts();
        closeWriteDialog();
    } catch
        (err) {
        alert(JSON.stringify(err));
    }
}

async function addPost() {
    try {
        let file = $('#write_attach')[0].files[0];
        let srcFile = new FormData();
        srcFile.append('srcFile', file);
        let response = await $.ajax({
            type: 'POST',
            url: '/post/attachment',
            data: srcFile,
            processData: false,
            contentType: false
        });
        let newPost = {
            title: $('#write_inputTitle').val(),
            comment: $('#write_inputContent').val(),
            attachedName: response.profileImageName,
            attachedPath: response.profileImagePath
        }
        let response2 = await $.ajax({
            type: "POST",
            url: "/post/add",
            contentType: "application/json",
            data: JSON.stringify(newPost)
        });
        $('#posts_list').prepend(`
                    <div class="posts" id="post_${response2.postIndex}" >
                        <img id="postImage_${response2.postIndex}" style="width: 250px;margin-left: -2%;height: 250px" src="${response2.attachedPath}">
                        <hr>
                        <div id="postTitle_${response2.postIndex}" style="font-size: 20pt">${response2.title}</div>
                        <div id="postComment_${response2.postIndex}" style="margin: 0 0 10px 10px">${response2.comment}</div>
                        <div style="position:absolute; bottom:0">
                            <button onclick="updatePostButtonClicked(${response2.postIndex})" class="postButtons" style="margin:0 7px 10px -15px;">수정</button>
                            <button onclick="closeUpdateDialog()" class="postButtons">삭제</button>
                        </div>
                    </div>
                `);
        if (response2.attachedPath === null || response2.attachedPath === "") {
            $(`#postImage_${response2.postIndex}`).attr("src", "/images/default/noimage.jpg");
        }
        $('#write_inputContent').val("");
        $('#write_inputTitle').val("");
        $('#write_attach').val("");
        closeWriteDialog();
    } catch (err) {
        alert(JSON.stringify(err));
    }
}

function checkIfLogined() {
    if (loginflag === 0) {
        alert("로그인을 해주세요");
        openLoginDialog();
        return true;
    } else {
        return false;
    }
}

// <img id="userImage_${user.id}" src="${user.profileImagePath}" class="profileImage">