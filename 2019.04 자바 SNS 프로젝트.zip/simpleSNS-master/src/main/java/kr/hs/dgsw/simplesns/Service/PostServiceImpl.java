package kr.hs.dgsw.simplesns.Service;

import kr.hs.dgsw.simplesns.Domain.Post;
import kr.hs.dgsw.simplesns.Repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Optional;

@Service
public class PostServiceImpl implements PostService {

    @Autowired
    public PostRepository postRepository;

    @PostConstruct
    void init(){
        this.postRepository.save(new Post("AAA","aaaaa"));
        this.postRepository.save(new Post("BBB","bbbbb"));
        this.postRepository.save(new Post("CCC","ccccc","/images/default/test.jpg","test.jpg"));
        this.postRepository.save(new Post("DDD","ddddd","/images/default/default.jpg","default.jpg"));
        this.postRepository.save(new Post("EEE","eeeee","/images/default/test.jpg","test.jpg"));
    }

    @Override
    public List<Post> listPost() {
        return this.postRepository.findAll();
    }

    @Override
    public Post addPost(Post post) {
        return this.postRepository.save(post);
    }

    @Override
    public Post updatePost(Long id, Post post) {
        Optional<Post> found = this.postRepository.findById(id);
        if (found.isPresent()) {
            Post p = found.get();
            p.setTitle(post.getTitle());
            p.setComment(post.getComment());
            p.setAttachedName(post.getAttachedName());
            p.setAttachedPath(post.getAttachedPath());
            return this.postRepository.save(p);
        } else {
            return null;
        }
    }


}
