package kr.hs.dgsw.simplesns.Controller;

import kr.hs.dgsw.simplesns.Domain.Post;
import kr.hs.dgsw.simplesns.Protocol.AttachmentProtocol;
import kr.hs.dgsw.simplesns.Service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLConnection;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@RestController
public class PostController {

    @Autowired
    public PostService postService;

    @GetMapping("/post/list")
    public List<Post> listPost() {
        return this.postService.listPost();
    }

    @PostMapping("/post/add")
    public Post addPost(@RequestBody Post post) {
        return this.postService.addPost(post);
    }

    @PostMapping("/post/update/{id}")
    public Post updatePost(@PathVariable Long id, @RequestBody Post post) {
        return this.postService.updatePost(id, post);
    }

    @PostMapping("/post/attachment")
    public AttachmentProtocol upload(@RequestPart MultipartFile srcFile) {
        System.out.println("============================");
        System.out.println(srcFile.getOriginalFilename());
        System.out.println("============================");
        String uid = UUID.randomUUID().toString();
        String destFilename
                = "D:/Java/SimpleSNS/uploads/"
                + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd/"))
                + uid
                + "_" + srcFile.getOriginalFilename();
        try {
            File destFile = new File(destFilename);
            destFile.getParentFile().mkdirs();
            srcFile.transferTo(destFile);
            destFilename = "images/"
                    + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd/"))
                    + uid
                    + "_" + srcFile.getOriginalFilename();
            return new AttachmentProtocol(destFilename, srcFile.getOriginalFilename());
        } catch (IOException e) {
            return null;
        }
    }


}
