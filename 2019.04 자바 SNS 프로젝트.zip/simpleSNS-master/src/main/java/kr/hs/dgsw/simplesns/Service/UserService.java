package kr.hs.dgsw.simplesns.Service;

import kr.hs.dgsw.simplesns.Domain.User;

public interface UserService {
    User addUser(User user);    //가입
    User loginUser(String userId,User user); //로그인할때
}
