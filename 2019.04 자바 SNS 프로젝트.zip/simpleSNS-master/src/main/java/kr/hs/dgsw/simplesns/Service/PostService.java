package kr.hs.dgsw.simplesns.Service;


import kr.hs.dgsw.simplesns.Domain.Post;

import java.util.List;

public interface PostService {
    List<Post> listPost();
    Post addPost(Post post);
    Post updatePost(Long id, Post post);
}
