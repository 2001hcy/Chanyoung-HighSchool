﻿using ENFRIEND.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ENFRIEND
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string Barcode = string.Empty;
        MediaPlayer media = new MediaPlayer();

        public MainWindow()
        {
            InitializeComponent();

            InitData();
            InitTimer();
        }

        private void InitData()
        {
          //  this.PreviewTextInput += MainWindow_PreviewTextInput;
            App.OrderEventViewModel.SearchEvent += OrderEventViewModel_SearchEvent;
            App.ProductViewModel.ChangePrice += ProductViewModel_ChangePrice;

            lvOrder.ItemsSource = App.ProductViewModel.lstOrder;
        }

        private void ProductViewModel_ChangePrice(int Sum, int Sale, int Total,int eco)
        {
            tbSum.Text = Sum.ToString();
            tbSale.Text = Sale.ToString();
            tbTotal.Text = Total.ToString();
            ecoPoint.Text = eco.ToString();
        }

        private void InitTimer()
        {
            DispatcherTimer timer = new DispatcherTimer();
             
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            tbTime.Text = DateTime.Now.ToLongTimeString();
        }

        private void OrderEventViewModel_SearchEvent(OrderEvent orderEvent)
        {
            SetImage(orderEvent.Picture);
            SetMusic(orderEvent.Sound);
        }

        private void SetMusic(string sound)
        {
            media.Close();
            if(sound != null)
            {
                media.Open(new Uri(@"D:\Users\STU\source\repos\ENFRIEND\ENFRIEND" + sound));
                media.Volume = 0.99;
                media.Play();
            }
        }

        private void SetImage(string path)
        {
            if(path != null)
            {
                imgStatus.Source = new BitmapImage(new Uri(path, UriKind.Relative));
            }
        }
#if false
        private void MainWindow_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Debug.WriteLine("MainWindow_PreviewTextInput");

            if (e.Text == "\r")
            {
                App.ProductViewModel.ADD(Barcode);
                Barcode = string.Empty;
                return;
            }
            Barcode += e.Text;
        }
#endif

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            string str = e.Key.ToString();

            if(e.Key == Key.Return)
            {
                if (CheckingSpecialText(Barcode))
                {
                    return;
                }
                App.ProductViewModel.ADD(Barcode);
                Barcode = string.Empty;
                e.Handled = true;

                    return;
            }

            e.Handled = true;
            Barcode += str.Substring(1, 1);
        }

        public bool CheckingSpecialText(string txt)
        {
            string str = @"[~!@\#$%^&*\()\=+|\\/:;?""<>']";
            System.Text.RegularExpressions.Regex rex = new System.Text.RegularExpressions.Regex(str);
            return rex.IsMatch(txt);
        }

        private void AddClick(object sender, RoutedEventArgs e)
        {
            Product product = lvOrder.SelectedItem as Product;
            App.ProductViewModel.ADD(product);

            lvOrder.SelectedItem = null;
        }

        private void SubClick(object sender, RoutedEventArgs e)
        {
            Product product = lvOrder.SelectedItem as Product;
            App.ProductViewModel.Sub(product);

            lvOrder.SelectedItem = null;
        }

        private void DelClick(object sender, RoutedEventArgs e)
        {
            Product product = lvOrder.SelectedItem as Product;
            App.ProductViewModel.Del(product);

            lvOrder.SelectedItem = null;
        }

        private void ClearClick(object sender, RoutedEventArgs e)
        {
            App.ProductViewModel.Clear();
        } 

        private void OrderClick(object sender, RoutedEventArgs e)
        {
            App.ProductViewModel.Order();
            App.ProductViewModel.Clear();
        }
    }
}
