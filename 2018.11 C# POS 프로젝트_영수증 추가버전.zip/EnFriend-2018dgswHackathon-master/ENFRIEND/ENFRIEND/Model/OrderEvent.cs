﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENFRIEND.Model
{
    public class OrderEvent
    {
        private int count;
        public int Count
        {
            get => count;
            set
            {
                count = value;
                Sound = @"\Resource\" + count + ".3gp";
                Picture = @"\Resource\" + count + ".jpg";
            }
        }

        public string Sound { get; set; }

        public string Picture { get; set; }
    }
}
