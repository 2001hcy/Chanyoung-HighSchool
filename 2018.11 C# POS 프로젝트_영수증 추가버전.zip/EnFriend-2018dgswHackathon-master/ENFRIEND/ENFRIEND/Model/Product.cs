﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENFRIEND.Model
{
    public enum Type
    {
        플라스틱,
        비닐,
        종이,
        캔,
        음식물,
        고무
    }

    public class Product : INotifyPropertyChanged
    {
        public string Name { get; set; }

        private int count;

        public int Count
        {
            get => count;
            set
            {
                count = value;
                OnPropertyChanged(nameof(Count));
            }
        }

        public string English { get; set; }

        public int Price { get; set; }

        private int total;
        public int Total
        {
            get => total;
            set
            {
                total = value;
                OnPropertyChanged(nameof(Total));
            }
        }

        public Type Type { get; set; }

        public string BarCode { get; set; }

        public string Picture { get; set; }

        public bool IsRecycle { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
