﻿using ENFRIEND.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENFRIEND.ViewModel
{

    public class OrderEventViewModel
    {
        public List<OrderEvent> lstOrderEvent { get; set; }

        public delegate void SearchEventHandler(OrderEvent orderEvent);
        public event SearchEventHandler SearchEvent;

        public OrderEventViewModel()
        {
            InitData();
        }
        private void InitData()
        {
            lstOrderEvent = new List<OrderEvent>();

            for (int i = 1; i <= 7; i++)
            {
                lstOrderEvent.Add(new OrderEvent() { Count = i });
            }

        }

        internal void CheckEvent(int plasticCnt, bool isRecycle = false, bool isPlastic = false)
        {
            OrderEvent orderEvent;

            if (isPlastic)
            {
                orderEvent = lstOrderEvent.Where(w => w.Count == plasticCnt).FirstOrDefault();

                if (plasticCnt >= 5)
                {
                    orderEvent = lstOrderEvent.Where(w => w.Count == 5).FirstOrDefault();
                }

                if (orderEvent == null)
                {
                    return;
                }
                
                SearchEvent?.Invoke(orderEvent);
                return;
            }

            if (isRecycle)
            {
                orderEvent = lstOrderEvent.Where(w => w.Count == 6).FirstOrDefault();
                SearchEvent?.Invoke(orderEvent);

                return;
            }
            orderEvent = lstOrderEvent.Where(w => w.Count == 7).FirstOrDefault();
            SearchEvent?.Invoke(orderEvent);

            return;

        }
    }
}
