﻿using ENFRIEND.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Type = ENFRIEND.Model.Type;

namespace ENFRIEND.ViewModel
{
    public class ProductViewModel
    {
        public ObservableCollection<Product> Items { get; set; }
        public ObservableCollection<Product> lstOrder { get; set; }

        public delegate void ChangePriceHandler(int Sum, int Sale, int Total, int ecoPoint);
        public event ChangePriceHandler ChangePrice;

        int PlasticCnt = 0;

        int Sum = 0;
        int Sale = 0;
        int Total = 0;
        int ecoPoint = 0;

        SerialPort Serial;

        public ProductViewModel()
        {
            InitData();
            InitSerial();
        }

        private void InitSerial()
        {
            Serial = new SerialPort();

            Serial.PortName = "COM5";
            Serial.BaudRate = 9600;
            Serial.Open();
        }

        private void InitData()
        {
            Items = new ObservableCollection<Product>();
            lstOrder = new ObservableCollection<Product>();

            //플라스틱
            Items.Add(new Product() { Name = "스파클(물)", English = "Sparkle 500ml", Count = 0, Price = 1000, Total = 0, Type = Type.플라스틱, BarCode = "1010502000018", IsRecycle = true });
            Items.Add(new Product() { Name = "볼펜심0.38mm(검)", English = "Pen seam(black)", Count = 0, Price = 2000, Total = 0, Type = Type.플라스틱, BarCode = "1010502000025", IsRecycle = false });
            Items.Add(new Product() { Name = "볼펜심0.38mm(파)", English = "Pen seam(blue)", Count = 0, Price = 2000, Total = 0, Type = Type.플라스틱, BarCode = "1010502000032", IsRecycle = false });
            Items.Add(new Product() { Name = "컴퓨터용 싸인펜", English = "Pen", Count = 0, Price = 800, Total = 0, Type = Type.플라스틱, BarCode = "1010502000049", IsRecycle = true });
            Items.Add(new Product() { Name = "볼펜", English = "Ball Pen", Count = 0, Price = 4000, Total = 0, Type = Type.플라스틱, BarCode = "1010502000056", IsRecycle = true });

            //고무
            Items.Add(new Product() { Name = "고무대야", English = "Rubber Big Night", Count = 0, Price = 10000, Total = 0, Type = Type.고무, BarCode = "2010502000062", IsRecycle = true });
            Items.Add(new Product() { Name = "고무호스", English = "Rubber Hose", Count = 0, Price = 20000, Total = 0, Type = Type.고무, BarCode = "2010502000079", IsRecycle = false });
            Items.Add(new Product() { Name = "마미손", English = "Mommy Son", Count = 0, Price = 2000, Total = 0, Type = Type.고무, BarCode = "2010502000086", IsRecycle = false });
            Items.Add(new Product() { Name = "고무줄", English = "Rubber Band", Count = 0, Price = 300, Total = 0, Type = Type.고무, BarCode = "2010502000093", IsRecycle = false });
            Items.Add(new Product() { Name = "지우개", English = "Eraser", Count = 0, Price = 500, Total = 0, Type = Type.고무, BarCode = "2010502000109", IsRecycle = false });

            //비닐
            Items.Add(new Product() { Name = "랩", English = "Wrap", Count = 0, Price = 1500, Total = 0, Type = Type.비닐, BarCode = "3010502000115", IsRecycle = false });
            Items.Add(new Product() { Name = "비닐우산", English = "Vynil Umbrella", Count = 0, Price = 3000, Total = 0, Type = Type.비닐, BarCode = "3010502000139", IsRecycle = true });
            Items.Add(new Product() { Name = "지퍼백", English = "Zipper Bag", Count = 0, Price = 200, Total = 0, Type = Type.비닐, BarCode = "3010502000146", IsRecycle = false });
            Items.Add(new Product() { Name = "커피우유", English = "Coffee Milk", Count = 0, Price = 1300, Total = 0, Type = Type.비닐, BarCode = "3010502000153", IsRecycle = false });
            Items.Add(new Product() { Name = "비닐장갑", English = "Vynil Glove", Count = 0, Price = 95000, Total = 0, Type = Type.비닐, BarCode = "3010502000160", IsRecycle = false });

            //캔
            Items.Add(new Product() { Name = "밀키스", English = "Milkis", Count = 0, Price = 1200, Total = 0, Type = Type.캔, BarCode = "4010502000176", IsRecycle = true });
            Items.Add(new Product() { Name = "펩시", English = "Pepsi", Count = 0, Price = 1300, Total = 0, Type = Type.캔, BarCode = "4010502000183", IsRecycle = true });
            Items.Add(new Product() { Name = "코카콜라", English = "Coke", Count = 0, Price = 1600, Total = 0, Type = Type.캔, BarCode = "4010502000190", IsRecycle = true });
            Items.Add(new Product() { Name = "솔의눈", English = "The eye of brush", Count = 0, Price = 3200, Total = 0, Type = Type.캔, BarCode = "4010502000206", IsRecycle = true });
            Items.Add(new Product() { Name = "핫식스", English = "Hot Six", Count = 0, Price = 2200, Total = 0, Type = Type.캔, BarCode = "4010502000213", IsRecycle = true });

            //종이
            Items.Add(new Product() { Name = "피크닉", English = "Picnic", Count = 0, Price = 600, Total = 0, Type = Type.종이, BarCode = "5010502000229", IsRecycle = true });
            Items.Add(new Product() { Name = "칸쵸", English = "Cancho", Count = 0, Price = 1100, Total = 0, Type = Type.종이, BarCode = "5010502000236", IsRecycle = true });
            Items.Add(new Product() { Name = "쿠크다스", English = "Cukdas", Count = 0, Price = 2200, Total = 0, Type = Type.종이, BarCode = "5010502000243", IsRecycle = true });
            Items.Add(new Product() { Name = "빼빼로", English = "PePero", Count = 0, Price = 1200, Total = 0, Type = Type.종이, BarCode = "5010502000250", IsRecycle = true });
            Items.Add(new Product() { Name = "빈츠", English = "Binz", Count = 0, Price = 2600, Total = 0, Type = Type.종이, BarCode = "5010502000267", IsRecycle = true });

            //음식물
            Items.Add(new Product() { Name = "치킨", English = "God", Count = 0, Price = 13000, Total = 0, Type = Type.음식물, BarCode = "6010502000273", IsRecycle = false });
            Items.Add(new Product() { Name = "피자", English = "Pizza", Count = 0, Price = 11000, Total = 0, Type = Type.음식물, BarCode = "6010502000280", IsRecycle = false });
            Items.Add(new Product() { Name = "햄버거", English = "Hamburger", Count = 0, Price = 6000, Total = 0, Type = Type.음식물, BarCode = "6010502000297", IsRecycle = false });
            Items.Add(new Product() { Name = "핫도그", English = "Hot dog", Count = 0, Price = 1500, Total = 0, Type = Type.음식물, BarCode = "6010502000303", IsRecycle = false });
            Items.Add(new Product() { Name = "계란", English = "Egg", Count = 0, Price = 3400, Total = 0, Type = Type.음식물, BarCode = "6010502000310", IsRecycle = false });
        }

        internal void Order()
        {
            string temp = "";
            string additional = "";

            foreach (Product product in lstOrder)
            {
                temp += product.English + "      /" + product.Total.ToString() + "    /" + product.Count.ToString();
                Serial.Write("\x02");
                Serial.Write(temp);
                Serial.Write("\x03");

                temp = string.Empty;
            }

            foreach (Product product in lstOrder)
            {
                if (product.IsRecycle)
                {

                    additional += product.English + "  CAN BE RECYClED\n";
                    Console.WriteLine(additional);
                    Serial.Write("\x02");
                    Serial.Write(additional);
                    Serial.Write("\x03");

                    additional = string.Empty;
                }
            }

            Serial_Print();
        }

        internal void Clear()
        {
            lstOrder.ToList().ForEach(s => s.Count = 0);
            lstOrder.Clear();

            CleraData();
            SetPrice();
        }

        private void CleraData()
        {
            PlasticCnt = 0;
            ecoPoint = 0;
        }

        internal void Del(Product product)
        {
            if (product == null)
            {
                return;
            }

            product.Count = 0;

            lstOrder.Remove(product);
            SetPrice();
        }

        internal void Sub(Product product)
        {
            if (product == null)
            {
                return;
            }

            product.Count--;
            product.Total = product.Count * product.Price;

            if (product.Count <= 0)
            {
                lstOrder.Remove(product);
            }
            SetPrice();
        }

        internal void ADD(Product product)
        {
            if (product == null)
            {
                return;
            }

            this.ADD(product.BarCode);
        }

        internal void ADD(string BarCode)
        {
            foreach (Product product in lstOrder)
            { //중복처리
                if (product.BarCode == BarCode)
                {
                    ChangeProduct(product);
                    SetPrice();
                    return;
                }
            }

            Product newProduct = Items.Where(w => w.BarCode == BarCode).FirstOrDefault();
            if(newProduct == null)
            { //이거 없으면 ㅈ댐
                return;
            }
            ChangeProduct(newProduct);
            lstOrder.Add(newProduct);

            SetPrice();
        }

        private void SetPrice()
        {
            Sum = 0;
            Sale = 0;

            foreach (Product product in lstOrder)
            {
                if (product == null)
                {
                    return;
                }
                Sum += product.Total;
            }

            Total = Sum - Sale;

            ChangePrice?.Invoke(Sum, Sale, Total, ecoPoint);
        }

        private void ChangeProduct(Product product)
        {
          /*  if (product == null)
            {
                return;
            }*/

            product.Count++;
            product.Total = product.Count * product.Price;

            if (product.Type == Type.플라스틱)
            {
                PlasticCnt++;
                App.OrderEventViewModel.CheckEvent(PlasticCnt, product.IsRecycle, true);
                if (product.IsRecycle)
                {
                    ecoPoint += (product.Price / 10);
                }

                return;
            }

            if (product.IsRecycle)
            {
                App.OrderEventViewModel.CheckEvent(PlasticCnt, true);
                ecoPoint += (product.Price / 10); //가격의 10%를 에코포인트로 저장

                return;
            }

            App.OrderEventViewModel.CheckEvent(PlasticCnt);
            return;
        }
        private void Serial_Print(string name, int price, int count)
        {
            //예시 : Serial_Print("COM3","Water",1000,2);
            //     => Water     2000    2 
            string temp = "";

            temp += name + "      /" + (price * count).ToString() + "    /   " + count.ToString();
            Serial.Write("\x02");
            Serial.Write(temp);
            Serial.Write("\x03");

            Serial.Write("\x02");
            Serial.Write("&");
            Serial.Write("\x03");
        }

        private void Serial_Print()
        {
            //예시 : Serial_Print("COM3","Water",1000,2);
            //     => Water     2000    2 



            Serial.Write("\x02");
            Serial.Write("&");
            Serial.Write("\x03");
        }

    }

}
