﻿using ENFRIEND.ViewModel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace ENFRIEND
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static ProductViewModel ProductViewModel = new ProductViewModel();
        public static OrderEventViewModel OrderEventViewModel = new OrderEventViewModel();
    }
}
