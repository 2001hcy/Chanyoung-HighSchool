package kr.hs.dgsw.dgswmall.Service;

import kr.hs.dgsw.dgswmall.Domain.User;
import kr.hs.dgsw.dgswmall.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public User register(User user) {
        Optional<User> find = this.userRepository.findById(user.getId());
        if (find.isPresent()) {
            return null;
        } else {
            return this.userRepository.save(user);
        }
    }

    @Override
    public User login(User user) {
        Optional<User> find = this.userRepository.findById(user.getId());
        if (find.isPresent()) {
            User temp = find.get();
            if (temp.getPassword().equals(user.getPassword())) {
                return temp;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }
}
