package kr.hs.dgsw.dgswmall.Service;

import kr.hs.dgsw.dgswmall.Domain.User;

public interface UserService {
    User register(User user);
    User login(User user);
}
