package kr.hs.dgsw.dgswmall.Service;

public interface ItemService {
    
}
